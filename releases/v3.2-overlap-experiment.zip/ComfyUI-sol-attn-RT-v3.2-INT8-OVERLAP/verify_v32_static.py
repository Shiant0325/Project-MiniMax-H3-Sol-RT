from pathlib import Path
import ast
root = Path(__file__).resolve().parent
for rel in [
    'sol_rt_v2_node.py', 'sol_kernel/rt_router.py', 'sol_kernel/rt_base_split.py',
    'sol_kernel/rt_compact.py', 'sol_kernel/rt_active.py'
]:
    ast.parse((root/rel).read_text(encoding='utf-8'), filename=rel)

host = (root/'sol_rt_native/rt_host.cu').read_text(encoding='utf-8')
assert 'sol_rt_route_async' in host
async_body = host.split('sol_rt_route_async',1)[1].split('sol_rt_group_size',1)[0]
assert 'cudaEventSynchronize(' not in async_body
assert 'cudaDeviceSynchronize(' not in async_body
assert 'optixLaunch' in async_body
node = (root/'sol_rt_v2_node.py').read_text(encoding='utf-8')
assert 'base_rt_overlap' in node
assert '_sol_attn_base_rt_overlap' in node
print('v3.2 static verification: PASS')
