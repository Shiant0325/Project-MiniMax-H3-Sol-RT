# MiniMax H3 Base-Sol RT v3.2 — INT8 two-stream overlap

This build adds a new backend: `base_rt_overlap`.

## What changed

The serial v3.1 path remains available as `base_rt_split`. The new overlap path keeps Base-Sol preparation, tau/threshold logic, local +/-1 exactness, conditioning sink behavior, CSR exact scheduling, and the INT8 QK/PV arithmetic, but changes execution scheduling inside one H3 attention call.

The attention sequence is divided into q-block slabs (`q_chunk_blocks`, default 32). A dedicated PyTorch CUDA stream submits centroid routing + native OptiX group routing. The normal/current stream consumes each completed route slab and launches the corresponding Base-Sol attention slab. Two ping-pong route buffers keep at most two route slabs in flight.

Steady-state intent:

```
RT stream:         route slab 0 | route slab 1 | route slab 2 | route slab 3 ...
attention stream:               wait 0 -> attn 0 | wait 1 -> attn 1 | ...
```

This is **q-slab overlap inside one attention invocation**. It does not attempt to route transformer layer N+1 while layer N is executing, because the next layer's Q/K/V depend on the previous layer output.

## Native API change — rebuild required

The v3.2 Python path requires a new DLL export:

`sol_rt_route_async(..., stream_ptr)`

Unlike the old hot path, that function has no `cudaEventSynchronize()` and no `cudaDeviceSynchronize()`. It launches group-max, OptiX, and output D2D copies onto the stream passed from PyTorch, then returns. The consumer stream waits on a CUDA event recorded after that work.

The ZIP still contains the previous DLL for serial fallback/reference. **Before using `base_rt_overlap`, run:**

```bat
build_sol_rt.cmd
```

The loader prefers `sol_rt_native\build\sol_rt_router.dll`, so the rebuilt DLL is automatically selected.

## First test settings

Use the same production-comparison settings as Base Sol:

- backend: `base_rt_overlap`
- rt_proof_mode: `native_rt`
- tau: `1.30`
- q_chunk_blocks: `32`
- int8_qk: `true`
- int8_pv: `true`
- sink_conditioning: `exact_kv`
- strict: `true`
- output_check_calls: `1`

The first overlap call performs the candidate false-negative validator. Later calls skip that per-slab host sync so the overlap itself is not destroyed by diagnostics. Output-check remains available for the requested first N calls.

## Automatic logs

The normal Sol-RT session JSONL now records overlap-specific fields:

- `route_stream_sum_ms`
- `compact_wall_ms`
- `overlap_pipeline_ms`
- `call_total_ms`
- `false_negative_blocks`
- `proof_mode`
- INT8 flags
- output-check fields when enabled

The console prefix is:

`[Base-Sol RT OVERLAP]`

## A/B benchmark

Use identical model, seed, prompt, resolution, frames, tau, INT8 flags, reserve/offload settings and steps.

1. `base_rt_split` — v3.1 serial reference.
2. `base_rt_overlap` — v3.2 two-stream build.
3. `base_sol` — final production target/reference.

The primary success metric is end-to-end denoise seconds/step. The overlap build is worthwhile only if `base_rt_overlap < base_rt_split`; the eventual target remains beating the Base-Sol INT8 baseline without quality loss.

## Hardware proof

The native overlap path still emits `SOL_RT_OPTIX_ROUTE_ASYNC` NVTX host ranges and calls OptiX through the native DLL. Use Nsight Systems/Graphics for external verification. The meaningful proof is an A/B capture where the native backend contains OptiX activity and the CUDA control/serial non-OptiX path does not.
