"""MiniMax H3 Sol-RT v2.2 compact routing node."""

from __future__ import annotations

import logging
import time

import torch

import comfy.model_management
import comfy.quant_ops

from .sol_kernel.fwd import (
    sol_attn,
    _validate,
    _use_pointer_arch,
    _forward_ptr,
    BLOCK,
    GROUP,
)
from .sol_kernel.preprocess import prepare
from .sol_kernel.rt_router import SolRTShadowValidator
from .sol_kernel.rt_active import (
    SolRTActiveError,
    SolRTActiveRouter,
    _forward_ptr_rt_active,
)
from .sol_kernel.rt_compact import compact_exact_csr, compact_exact_csr_slab
from .sol_kernel.rt_base_split import (
    BaseRTSplitRouter,
    _forward_base_rt_split,
    _forward_base_rt_split_int8,
)
from .minimax import _install_span_injector, _Unsupported

log = logging.getLogger(__name__)


def _sol_attn_active(
    q, k, v, router,
    *,
    block_id,
    scale=None,
    tau=1.3,
    thresh_type="diag",
    int8_qk=False,
    int8_pv=False,
    sink_blocks=(0, 0),
    sink_q=(0, 0),
):
    arch = _validate(q, k, v, 1, thresh_type)
    if arch != (12, 0) or not _use_pointer_arch(arch):
        raise _Unsupported("Sol-RT active v2 requires SM120 pointer path")

    scale = q.shape[-1] ** -0.5 if scale is None else float(scale)
    batch, tokens, heads, head_dim = q.shape
    blocks = (tokens + BLOCK - 1) // BLOCK
    output = torch.empty_like(q)

    # Same Sol summary + threshold preparation as base BF16 Sol.
    kc, vc, threshold = prepare(
        q, k, v, tau=float(tau), scale=scale, thresh_type=thresh_type
    )

    call_wall0 = time.perf_counter()
    route_mask, metrics = router.build_route_mask(q, kc, threshold, scale)

    sinks = (
        int(sink_blocks[0]), int(sink_blocks[1]),
        int(sink_q[0]), int(sink_q[1]),
    )

    ev0 = torch.cuda.Event(enable_timing=True)
    ev1 = torch.cuda.Event(enable_timing=True)
    ev0.record()
    _forward_ptr_rt_active[(1, blocks, batch * heads)](
        q, k, v, kc, vc, route_mask, output,
        scale,
        *sinks,
        tokens,
        q.stride(0), q.stride(1), q.stride(2),
        k.stride(0), k.stride(1), k.stride(2),
        v.stride(0), v.stride(1), v.stride(2),
        H=heads,
        D=head_dim,
        NT=blocks,
        BV=head_dim,
        BLOCK_SIZE=BLOCK,
        GROUP_SIZE=GROUP,
    )
    ev1.record()
    ev1.synchronize()
    attention_ms = ev0.elapsed_time(ev1)
    call_total_ms = (time.perf_counter() - call_wall0) * 1000.0

    rec = dict(metrics)
    rec.update({
        "timestamp": __import__("datetime").datetime.now().isoformat(timespec="milliseconds"),
        "block_id": int(block_id),
        "attention_ms": float(attention_ms),
        "call_total_ms": float(call_total_ms),
        "fallback": False,
    })
    router.logger.record(rec)

    log.info(
        "[Sol-RT] ACTIVE block=%d call=%d attention=%.2fms total=%.2fms false_neg=%d",
        block_id, metrics["call"], attention_ms, call_total_ms,
        metrics["false_negative_blocks"],
    )
    return output




def _sol_attn_base_rt_split(
    q, k, v, router,
    *,
    block_id,
    exact_list_capacity=512,
    output_check=False,
    scale=None,
    tau=1.3,
    thresh_type="diag",
    int8_qk=False,
    int8_pv=False,
    sink_blocks=(0, 0),
    sink_q=(0, 0),
):
    arch = _validate(q, k, v, 1, thresh_type)
    if arch != (12, 0) or not _use_pointer_arch(arch):
        raise _Unsupported("Base-Sol RT Split requires SM120 pointer path")

    scale = q.shape[-1] ** -0.5 if scale is None else float(scale)
    batch, tokens, heads, head_dim = q.shape
    blocks = (tokens + BLOCK - 1) // BLOCK
    output = torch.empty_like(q)

    # Match Base Sol precision mode.
    if int8_pv and not int8_qk:
        raise _Unsupported("int8_pv requires int8_qk")

    if int8_qk:
        if int8_pv:
            from .sol_kernel.quant import quantize_v_per_channel
            (
                kc, vc, threshold,
                q8, q_scale,
                k8, k_scale,
                v_absmax,
            ) = prepare(
                q, k, v,
                tau=float(tau),
                scale=scale,
                thresh_type=thresh_type,
                int8_qk=True,
                int8_pv=True,
            )
            vi, v_scale = quantize_v_per_channel(
                v, absmax=v_absmax
            )
        else:
            (
                kc, vc, threshold,
                q8, q_scale,
                k8, k_scale,
            ) = prepare(
                q, k, v,
                tau=float(tau),
                scale=scale,
                thresh_type=thresh_type,
                int8_qk=True,
                int8_pv=False,
            )
            vi, v_scale = q8, q_scale  # unused
    else:
        kc, vc, threshold = prepare(
            q, k, v,
            tau=float(tau),
            scale=scale,
            thresh_type=thresh_type,
        )

    wall0 = time.perf_counter()

    # RT threshold routing using centroid score identity.
    threshold_mask, metrics = router.build_threshold_mask(
        q, kc, threshold, scale
    )

    # Add local +/-1 and sink exactness exactly as Base Sol.
    (
        exact_offsets,
        exact_idx,
        exact_count,
        max_exact,
        total_exact,
        compact_ms,
    ) = compact_exact_csr(
        threshold_mask,
        sink_blocks=sink_blocks,
        sink_q=sink_q,
    )

    # Build final exact mask once so the Base summary pass can exclude exact blocks
    # without re-performing route reduction. Reuse threshold mask storage.
    BH = batch * heads
    N = blocks
    qb = torch.arange(N, device=q.device)[:, None]
    kvb = torch.arange(N, device=q.device)[None, :]
    local = (qb - kvb).abs() <= 1
    final_mask = threshold_mask.bool()
    final_mask |= local[None, :, :]

    ss, se = int(sink_blocks[0]), int(sink_blocks[1])
    if se > ss:
        final_mask[:, :, ss:se] = True

    qs, qe = int(sink_q[0]), int(sink_q[1])
    if qe > qs:
        final_mask[:, qs:qe, :] = True

    final_mask = final_mask.to(torch.uint8)

    e0 = torch.cuda.Event(enable_timing=True)
    e1 = torch.cuda.Event(enable_timing=True)
    e0.record()
    if int8_qk:
        _forward_base_rt_split_int8[(1, blocks, batch * heads)](
            q, v,
            kc, vc,
            q8, k8,
            q_scale, k_scale,
            vi, v_scale,
            final_mask,
            exact_offsets, exact_idx,
            output,
            scale,
            int(max_exact),
            0, blocks,
            tokens,
            q.stride(0), q.stride(1), q.stride(2),
            v.stride(0), v.stride(1), v.stride(2),
            H=heads,
            D=head_dim,
            NT=blocks,
            BV=head_dim,
            BLOCK_SIZE=BLOCK,
            GROUP_SIZE=GROUP,
            INT8_PV=bool(int8_pv),
        )
    else:
        _forward_base_rt_split[(1, blocks, batch * heads)](
            q, k, v,
            kc, vc,
            final_mask,
            exact_offsets, exact_idx,
            output,
            scale,
            int(max_exact),
            0, blocks,
            tokens,
            q.stride(0), q.stride(1), q.stride(2),
            k.stride(0), k.stride(1), k.stride(2),
            v.stride(0), v.stride(1), v.stride(2),
            H=heads,
            D=head_dim,
            NT=blocks,
            BV=head_dim,
            BLOCK_SIZE=BLOCK,
            GROUP_SIZE=GROUP,
        )
    e1.record()
    e1.synchronize()

    attention_ms = e0.elapsed_time(e1)
    total_ms = (time.perf_counter() - wall0) * 1000.0

    rec = dict(metrics)
    rec.update({
        "timestamp":
            __import__("datetime").datetime.now().isoformat(
                timespec="milliseconds"
            ),
        "block_id": int(block_id),
        "compact_ms": float(compact_ms),
        "max_exact_per_row": int(max_exact),
        "total_exact_indices": int(total_exact),
        "attention_ms": float(attention_ms),
        "call_total_ms": float(total_ms),
        "fallback": False,
        "backend": "base_rt_split",
        "int8_qk": bool(int8_qk),
        "int8_pv": bool(int8_pv),
    })

    if output_check:
        ref = sol_attn(
            q, k, v,
            scale=scale,
            tau=float(tau),
            thresh_type=thresh_type,
            int8_qk=bool(int8_qk),
            int8_pv=bool(int8_pv),
            sink_blocks=sink_blocks,
            sink_q=sink_q,
        )
        diff = (output.float() - ref.float()).abs()
        rec["output_check_max_abs"] = float(diff.max().item())
        rec["output_check_mean_abs"] = float(diff.mean().item())
        rec["output_check_exact_pct"] = float(
            (output == ref).float().mean().item() * 100.0
        )
        log.info(
            "[Base-Sol RT] output-check block=%d "
            "max_abs=%.8f mean_abs=%.8f exact=%.3f%%",
            block_id,
            rec["output_check_max_abs"],
            rec["output_check_mean_abs"],
            rec["output_check_exact_pct"],
        )

    router.logger.record(rec)

    log.info(
        "[Base-Sol RT] CSR block=%d call=%d exact_max=%d total_exact=%d "
        "compact=%.2fms attention=%.2fms total=%.2fms false_neg=%d",
        block_id,
        metrics["call"],
        max_exact,
        total_exact,
        compact_ms,
        attention_ms,
        total_ms,
        metrics["false_negative_blocks"],
    )
    return output


def _sol_attn_base_rt_overlap(
    q, k, v, router,
    *,
    block_id,
    output_check=False,
    scale=None,
    tau=1.3,
    thresh_type="diag",
    int8_qk=False,
    int8_pv=False,
    sink_blocks=(0, 0),
    sink_q=(0, 0),
):
    """v3.2 two-stream q-slab pipeline: RT route(i+1) overlaps attention(i)."""
    arch = _validate(q, k, v, 1, thresh_type)
    if arch != (12, 0) or not _use_pointer_arch(arch):
        raise _Unsupported("Base-Sol RT Overlap requires SM120 pointer path")
    if router.proof_mode != "native_rt":
        raise _Unsupported("base_rt_overlap requires rt_proof_mode=native_rt")

    scale = q.shape[-1] ** -0.5 if scale is None else float(scale)
    batch, tokens, heads, head_dim = q.shape
    blocks = (tokens + BLOCK - 1) // BLOCK
    BH = batch * heads
    qc_fixed = int(router.q_chunk_blocks)
    output = torch.empty_like(q)

    if int8_pv and not int8_qk:
        raise _Unsupported("int8_pv requires int8_qk")

    # Identical Base-Sol preparation / INT8 arithmetic inputs.
    if int8_qk:
        if int8_pv:
            from .sol_kernel.quant import quantize_v_per_channel
            kc, vc, threshold, q8, q_scale, k8, k_scale, v_absmax = prepare(
                q, k, v, tau=float(tau), scale=scale,
                thresh_type=thresh_type, int8_qk=True, int8_pv=True,
            )
            vi, v_scale = quantize_v_per_channel(v, absmax=v_absmax)
        else:
            kc, vc, threshold, q8, q_scale, k8, k_scale = prepare(
                q, k, v, tau=float(tau), scale=scale,
                thresh_type=thresh_type, int8_qk=True, int8_pv=False,
            )
            vi, v_scale = q8, q_scale  # unused
    else:
        kc, vc, threshold = prepare(
            q, k, v, tau=float(tau), scale=scale, thresh_type=thresh_type
        )

    router.calls += 1
    call = int(router.calls)
    step = ((call - 1) // max(1, router.blocks_per_step)) + 1
    wall0 = time.perf_counter()
    slabs = [(qs, min(qc_fixed, blocks - qs)) for qs in range(0, blocks, qc_fixed)]
    tickets = {}
    submit_cursor = 0

    # Prime two ping-pong slots. Native work is queued only on the dedicated RT stream.
    while submit_cursor < min(2, len(slabs)):
        qs0, qc0 = slabs[submit_cursor]
        tickets[submit_cursor] = router.submit_overlap_slab(
            q, kc, threshold, scale, qs0, qc0, submit_cursor & 1
        )
        submit_cursor += 1

    total_exact = 0
    total_false_neg = 0
    route_ms_total = 0.0
    compact_wall_ms = 0.0
    current = torch.cuda.current_stream(q.device)
    pipeline_start = torch.cuda.Event(enable_timing=True)
    pipeline_end = torch.cuda.Event(enable_timing=True)
    pipeline_start.record(current)

    for slab_i, (qs0, qc0) in enumerate(slabs):
        ticket = tickets.pop(slab_i)
        # First call keeps the strong candidate-vs-threshold validator. Later calls
        # avoid the per-slab host sync so overlap is not destroyed by diagnostics.
        threshold_mask, false_neg = router.finalize_overlap_slab(
            ticket, verify=bool(router.strict and call == 1)
        )
        total_false_neg += int(false_neg)

        # The source ping-pong slot is now protected by a release event. Queue the
        # next RT slab immediately; its stream waits only for that release event,
        # then can overlap the compact/attention work below.
        if submit_cursor < len(slabs):
            qsn, qcn = slabs[submit_cursor]
            tickets[submit_cursor] = router.submit_overlap_slab(
                q, kc, threshold, scale, qsn, qcn, submit_cursor & 1
            )
            submit_cursor += 1

        qbi = torch.arange(qs0, qs0 + qc0, device=q.device)[:, None]
        kvb = torch.arange(blocks, device=q.device)[None, :]
        final_mask = threshold_mask.bool()
        final_mask |= ((qbi - kvb).abs() <= 1)[None, :, :]
        ss, se = int(sink_blocks[0]), int(sink_blocks[1])
        if se > ss:
            final_mask[:, :, ss:se] = True
        sqs, sqe = int(sink_q[0]), int(sink_q[1])
        if sqe > sqs:
            row_sel = (qbi[:, 0] >= sqs) & (qbi[:, 0] < sqe)
            if bool(row_sel.any().item()):
                final_mask[:, row_sel, :] = True
        final_mask = final_mask.to(torch.uint8)

        c0 = time.perf_counter()
        exact_offsets, exact_idx, exact_count, slab_exact = compact_exact_csr_slab(
            threshold_mask,
            q_block_start=qs0,
            total_blocks=blocks,
            sink_blocks=sink_blocks,
            sink_q=sink_q,
        )
        compact_wall_ms += (time.perf_counter() - c0) * 1000.0
        total_exact += int(slab_exact)

        # N is a safe runtime upper bound; avoids a max-count .item() sync.
        if int8_qk:
            _forward_base_rt_split_int8[(1, qc0, BH)](
                q, v, kc, vc,
                q8, k8, q_scale, k_scale, vi, v_scale,
                final_mask, exact_offsets, exact_idx, output,
                scale, blocks, qs0, qc0, tokens,
                q.stride(0), q.stride(1), q.stride(2),
                v.stride(0), v.stride(1), v.stride(2),
                H=heads, D=head_dim, NT=blocks, BV=head_dim,
                BLOCK_SIZE=BLOCK, GROUP_SIZE=GROUP,
                INT8_PV=bool(int8_pv),
            )
        else:
            _forward_base_rt_split[(1, qc0, BH)](
                q, k, v, kc, vc,
                final_mask, exact_offsets, exact_idx, output,
                scale, blocks, qs0, qc0, tokens,
                q.stride(0), q.stride(1), q.stride(2),
                k.stride(0), k.stride(1), k.stride(2),
                v.stride(0), v.stride(1), v.stride(2),
                H=heads, D=head_dim, NT=blocks, BV=head_dim,
                BLOCK_SIZE=BLOCK, GROUP_SIZE=GROUP,
            )

        # compact_exact_csr_slab performs one scalar consumer sync, so the RT
        # completion event is already queryable here without an extra hot-path sync.
        try:
            route_ms_total += ticket["route_start"].elapsed_time(ticket["route_done"])
        except Exception:
            pass

    pipeline_end.record(current)
    pipeline_end.synchronize()
    pipeline_ms = pipeline_start.elapsed_time(pipeline_end)
    total_ms = (time.perf_counter() - wall0) * 1000.0

    rec = {
        "timestamp": __import__("datetime").datetime.now().isoformat(timespec="milliseconds"),
        "call": call, "step": step, "block_id": int(block_id),
        "tokens": int(tokens), "route_blocks": int(blocks),
        "q_chunk_blocks": int(qc_fixed), "slabs": len(slabs),
        "proof_mode": router.proof_mode,
        "false_negative_blocks": int(total_false_neg),
        "total_exact_indices": int(total_exact),
        "route_stream_sum_ms": float(route_ms_total),
        "compact_wall_ms": float(compact_wall_ms),
        "overlap_pipeline_ms": float(pipeline_ms),
        "call_total_ms": float(total_ms),
        "backend": "base_rt_overlap",
        "int8_qk": bool(int8_qk), "int8_pv": bool(int8_pv),
        "fallback": False,
    }

    if output_check:
        ref = sol_attn(
            q, k, v, scale=scale, tau=float(tau), thresh_type=thresh_type,
            int8_qk=bool(int8_qk), int8_pv=bool(int8_pv),
            sink_blocks=sink_blocks, sink_q=sink_q,
        )

        # Memory-safe correctness check.  The old v3.2 code materialized
        # output.float(), ref.float(), and a full FP32 diff tensor at once,
        # which can add >1.5 GiB at this H3 shape.  Compare in small flat
        # chunks and keep only scalar accumulators on-device.
        out_flat = output.reshape(-1)
        ref_flat = ref.reshape(-1)
        n_elem = int(out_flat.numel())
        chunk_elems = 1 << 20  # ~1M elements; low transient VRAM overhead

        max_abs = torch.zeros((), device=output.device, dtype=torch.float32)
        sum_abs = torch.zeros((), device=output.device, dtype=torch.float64)
        exact_count = torch.zeros((), device=output.device, dtype=torch.int64)

        with torch.no_grad():
            for start in range(0, n_elem, chunk_elems):
                stop = min(start + chunk_elems, n_elem)
                a = out_flat[start:stop].float()
                b = ref_flat[start:stop].float()
                d = (a - b).abs()
                max_abs = torch.maximum(max_abs, d.max())
                sum_abs += d.sum(dtype=torch.float64)
                exact_count += (out_flat[start:stop] == ref_flat[start:stop]).sum(dtype=torch.int64)
                del a, b, d

        rec["output_check_max_abs"] = float(max_abs.item())
        rec["output_check_mean_abs"] = float((sum_abs / max(n_elem, 1)).item())
        rec["output_check_exact_pct"] = float((exact_count.float() * (100.0 / max(n_elem, 1))).item())
        del ref, out_flat, ref_flat, max_abs, sum_abs, exact_count

    router.logger.record(rec)
    log.info(
        "[Base-Sol RT OVERLAP] block=%d call=%d slabs=%d route_sum=%.2fms "
        "compact=%.2fms pipeline=%.2fms total=%.2fms false_neg=%d",
        block_id, call, len(slabs), route_ms_total, compact_wall_ms,
        pipeline_ms, total_ms, total_false_neg,
    )
    return output


def _sol_attn_compact(
    q, k, v, router,
    *,
    block_id,
    exact_list_capacity=512,
    output_check=False,
    scale=None,
    tau=1.3,
    thresh_type="diag",
    sink_blocks=(0, 0),
    sink_q=(0, 0),
):
    arch = _validate(q, k, v, 1, thresh_type)
    if arch != (12, 0) or not _use_pointer_arch(arch):
        raise _Unsupported("Sol-RT compact v2.2 requires SM120 pointer path")

    scale = q.shape[-1] ** -0.5 if scale is None else float(scale)
    batch, tokens, heads, head_dim = q.shape
    blocks = (tokens + BLOCK - 1) // BLOCK
    output = torch.empty_like(q)

    kc, vc, threshold = prepare(
        q, k, v, tau=float(tau), scale=scale, thresh_type=thresh_type
    )

    call_wall0 = time.perf_counter()
    route_mask, metrics = router.build_route_mask(q, kc, threshold, scale)

    exact_idx, exact_count, max_exact, compact_ms = compact_exact_list(
        route_mask,
        sink_blocks=sink_blocks,
        sink_q=sink_q,
        capacity=int(exact_list_capacity),
    )

    sinks = (
        int(sink_blocks[0]), int(sink_blocks[1]),
        int(sink_q[0]), int(sink_q[1]),
    )

    ev0 = torch.cuda.Event(enable_timing=True)
    ev1 = torch.cuda.Event(enable_timing=True)
    ev0.record()
    _forward_ptr_compact[(1, blocks, batch * heads)](
        q, k, v,
        kc, vc,
        route_mask,
        exact_idx, exact_count,
        output,
        scale,
        *sinks,
        int(max_exact),
        tokens,
        q.stride(0), q.stride(1), q.stride(2),
        k.stride(0), k.stride(1), k.stride(2),
        v.stride(0), v.stride(1), v.stride(2),
        H=heads,
        D=head_dim,
        NT=blocks,
        CAP=int(exact_list_capacity),
        BV=head_dim,
        BLOCK_SIZE=BLOCK,
        GROUP_SIZE=GROUP,
    )
    ev1.record()
    ev1.synchronize()
    attention_ms = ev0.elapsed_time(ev1)
    call_total_ms = (time.perf_counter() - call_wall0) * 1000.0

    rec = dict(metrics)
    rec.update({
        "timestamp": __import__("datetime").datetime.now().isoformat(timespec="milliseconds"),
        "block_id": int(block_id),
        "compact_ms": float(compact_ms),
        "max_exact_per_row": int(max_exact),
        "attention_ms": float(attention_ms),
        "call_total_ms": float(call_total_ms),
        "fallback": False,
        "backend": "compact_rt",
    })

    if output_check:
        ref = sol_attn(
            q, k, v,
            scale=scale,
            tau=float(tau),
            thresh_type=thresh_type,
            int8_qk=False,
            int8_pv=False,
            sink_blocks=sink_blocks,
            sink_q=sink_q,
        )
        diff = (output.float() - ref.float()).abs()
        rec["output_check_max_abs"] = float(diff.max().item())
        rec["output_check_mean_abs"] = float(diff.mean().item())
        rec["output_check_exact_pct"] = float(
            (output == ref).float().mean().item() * 100.0
        )
        log.info(
            "[Sol-RT] COMPACT output-check block=%d max_abs=%.8f mean_abs=%.8f exact=%.3f%%",
            block_id,
            rec["output_check_max_abs"],
            rec["output_check_mean_abs"],
            rec["output_check_exact_pct"],
        )

    router.logger.record(rec)
    log.info(
        "[Sol-RT] COMPACT block=%d call=%d exact_max=%d compact=%.2fms "
        "attention=%.2fms total=%.2fms false_neg=%d",
        block_id, metrics["call"], max_exact, compact_ms,
        attention_ms, call_total_ms, metrics["false_negative_blocks"],
    )
    return output


def _sol_attn_shadow(
    q, k, v, validator, *,
    scale=None, tau=1.3, thresh_type="diag",
    sink_blocks=(0, 0), sink_q=(0, 0),
):
    """Original v1 shadow path retained for A/B validation."""
    arch = _validate(q, k, v, 1, thresh_type)
    if arch != (12, 0) or not _use_pointer_arch(arch):
        return sol_attn(
            q, k, v, scale=scale, tau=tau, thresh_type=thresh_type,
            sink_blocks=sink_blocks, sink_q=sink_q,
        )

    scale = q.shape[-1] ** -0.5 if scale is None else float(scale)
    batch, tokens, heads, head_dim = q.shape
    blocks = (tokens + BLOCK - 1) // BLOCK
    output = torch.empty_like(q)

    kc, vc, threshold = prepare(
        q, k, v, tau=float(tau), scale=scale, thresh_type=thresh_type
    )
    validator.validate(q, kc, threshold, scale)

    sinks = (
        int(sink_blocks[0]), int(sink_blocks[1]),
        int(sink_q[0]), int(sink_q[1]),
    )
    _forward_ptr[(1, blocks, batch * heads)](
        q, k, v, kc, vc, threshold, output,
        scale,
        *sinks,
        tokens,
        q.stride(0), q.stride(1), q.stride(2),
        k.stride(0), k.stride(1), k.stride(2),
        v.stride(0), v.stride(1), v.stride(2),
        H=heads,
        D=head_dim,
        NT=blocks,
        BV=head_dim,
        BLOCK_SIZE=BLOCK,
        GROUP_SIZE=GROUP,
    )
    return output


def _make_forward(
    attn,
    fallback_forward,
    *,
    block_id,
    backend,
    active_router,
    shadow_validator,
    tau,
    min_tokens,
    strict,
    thresh_type,
    sink_conditioning,
    int8_qk,
    int8_pv,
    exact_list_capacity=512,
    output_check_calls=1,
):
    heads, head_dim = attn.heads, attn.head_dim
    inner = heads * head_dim

    def forward(x, rope_freqs=None, transformer_options={}):
        handoff = isinstance(x, list) and len(x) == 1 and torch.is_tensor(x[0])
        tensor = x[0] if handoff else x
        handoff_released = False

        try:
            if not torch.is_tensor(tensor):
                raise _Unsupported("attention input is not a tensor")
            s = tensor.shape[0]
            if tensor.ndim != 2 or s < min_tokens or tensor.requires_grad:
                raise _Unsupported("below min_tokens or autograd requested")
            if tensor.dtype != torch.bfloat16 or tensor.device.type != "cuda":
                raise _Unsupported("requires bfloat16 on CUDA")
            if head_dim != 128:
                raise _Unsupported(f"head_dim {head_dim} != 128")
            if torch.cuda.get_device_capability(tensor.device) != (12, 0):
                raise _Unsupported("Sol-RT v2 requires SM120")

            # active_rt v2.1 always uses the proven BF16 route.
            # Old workflows may still carry INT8 toggles; ignore them here instead
            # of silently falling back away from RT generation.
            active_int8_qk = bool(int8_qk)
            active_int8_pv = bool(int8_pv)

            sink_blocks = (0, 0)
            sink_q = (0, 0)
            if sink_conditioning != "off":
                span = (transformer_options or {}).get("sol_h3_video_span")
                if span is not None:
                    video_start, video_stop = span
                    if 0 < video_start and s >= video_stop:
                        sink_blocks = (0, (video_start + 63) // 64)
                        if sink_conditioning == "exact_kv_and_rows":
                            sink_q = sink_blocks

            if handoff:
                tensor = x.pop()

            device = tensor.device
            q, k, v = attn.qkv_proj(tensor).split(inner, dim=-1)
            if handoff:
                del tensor
                handoff_released = True

            q = q.view(1, s, heads, head_dim)
            k = k.view(1, s, heads, head_dim)
            v = v.view(1, s, heads, head_dim)

            if rope_freqs is not None:
                qw = comfy.model_management.cast_to(attn.q_norm.weight, device=device)
                kw = comfy.model_management.cast_to(attn.k_norm.weight, device=device)
                comfy.quant_ops.ck.rms_rope_split_half_(
                    q, k, rope_freqs, qw, kw,
                    epsilon=attn.q_norm.eps,
                    rot_dim=rope_freqs.shape[-3] * 2,
                )
            else:
                q = attn.q_norm(q)
                k = attn.k_norm(k)

            if backend == "base_rt_overlap":
                if sink_conditioning == "exact_kv":
                    sink_q = (0, 0)
                out = _sol_attn_base_rt_overlap(
                    q, k, v, active_router,
                    block_id=block_id,
                    output_check=(active_router.calls < int(output_check_calls)),
                    tau=float(tau),
                    thresh_type=thresh_type,
                    int8_qk=active_int8_qk,
                    int8_pv=active_int8_pv,
                    sink_blocks=sink_blocks,
                    sink_q=sink_q,
                )
            elif backend == "base_rt_split":
                if sink_conditioning == "exact_kv":
                    sink_q = (0, 0)
                out = _sol_attn_base_rt_split(
                    q, k, v, active_router,
                    block_id=block_id,
                    exact_list_capacity=int(exact_list_capacity),
                    output_check=(active_router.calls < int(output_check_calls)),
                    tau=float(tau),
                    thresh_type=thresh_type,
                    int8_qk=active_int8_qk,
                    int8_pv=active_int8_pv,
                    sink_blocks=sink_blocks,
                    sink_q=sink_q,
                )
            elif backend == "compact_rt":
                raise _Unsupported(
                    "compact_rt fixed-cap backend retired in v3.1; use base_rt_split"
                )
            elif backend == "active_rt":
                out = _sol_attn_active(
                    q, k, v, active_router,
                    block_id=block_id,
                    tau=float(tau),
                    thresh_type=thresh_type,
                    sink_blocks=sink_blocks,
                    sink_q=sink_q,
                )
            elif backend == "shadow_validate":
                out = _sol_attn_shadow(
                    q, k, v, shadow_validator,
                    tau=float(tau),
                    thresh_type=thresh_type,
                    sink_blocks=sink_blocks,
                    sink_q=sink_q,
                )
            else:
                out = sol_attn(
                    q, k, v,
                    tau=float(tau),
                    thresh_type=thresh_type,
                    int8_qk=active_int8_qk,
                    int8_pv=active_int8_pv,
                    sink_blocks=sink_blocks,
                    sink_q=sink_q,
                )

            return attn.out_proj(out.view(s, inner))

        except (_Unsupported, SolRTActiveError) as e:
            log.warning("[Sol-RT] block=%d fallback: %s", block_id, e)
            if strict and isinstance(e, SolRTActiveError):
                raise
        except Exception:
            if strict:
                raise
            log.exception("[Sol-RT] block=%d active error; using fallback", block_id)

        if handoff and not x:
            if handoff_released:
                raise RuntimeError(
                    "Sol-RT fallback requested after Comfy handoff was released; "
                    "use strict=true to diagnose the original error."
                )
            return fallback_forward(
                tensor,
                rope_freqs=rope_freqs,
                transformer_options=transformer_options,
            )

        return fallback_forward(
            x,
            rope_freqs=rope_freqs,
            transformer_options=transformer_options,
        )

    forward._minimax_h3_sol_rt_fallback = fallback_forward
    return forward


class MiniMaxH3SolRTActivePatch:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL",),
                "enabled": ("BOOLEAN", {"default": True}),
                "backend": (
                    ["base_rt_overlap", "base_rt_split", "compact_rt", "active_rt", "shadow_validate", "base_sol"],
                    {"default": "base_rt_overlap"},
                ),
                "rt_proof_mode": (
                    ["native_rt", "cuda_control"],
                    {
                        "default": "native_rt",
                        "tooltip": (
                            "native_rt calls OptiX and emits SOL_RT_OPTIX_ROUTE NVTX ranges. "
                            "cuda_control never calls the native RT route and reproduces the "
                            "same 8-block candidate predicate with CUDA for A/B profiling."
                        ),
                    },
                ),
                "tau": ("FLOAT", {
                    "default": 1.30, "min": 0.0, "max": 4.0, "step": 0.05
                }),
                "min_tokens": ("INT", {
                    "default": 4096, "min": 256, "max": 262144, "step": 256
                }),
                "q_chunk_blocks": ("INT", {
                    "default": 32, "min": 1, "max": 64, "step": 1,
                    "tooltip": "Sol query blocks per persistent RT slab. 32 = 2048 query tokens and far fewer RT launches."
                }),
                "exact_list_capacity": ("INT", {
                    "default": 512, "min": 128, "max": 2048, "step": 64,
                    "tooltip": "Legacy control; ignored by base_rt_split v3.1 CSR (no fixed capacity)."
                }),
                "output_check_calls": ("INT", {
                    "default": 1, "min": 0, "max": 10, "step": 1,
                    "tooltip": "Run Base Sol too for the first N compact calls and log output differences."
                }),
                "strict": ("BOOLEAN", {"default": True}),
                "thresh_type": (["diag", "exact"], {"default": "diag"}),
                "int8_qk": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "Supported by base_sol. v2.2 compact_rt is BF16 only."
                }),
                "int8_pv": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "Supported by base_sol and base_rt_split v3.1-INT8. Requires int8_qk."
                }),
                "sink_conditioning": (
                    ["exact_kv", "exact_kv_and_rows", "off"],
                    {"default": "exact_kv"},
                ),
                "dll_path": ("STRING", {
                    "default": "",
                    "tooltip": "Blank auto-detects sol_rt_native/sol_rt_router.dll."
                }),
                "log_files": ("BOOLEAN", {"default": True}),
                "log_dir": ("STRING", {
                    "default": "",
                    "tooltip": "Blank = ComfyUI/output/sol_rt_logs."
                }),
            }
        }

    RETURN_TYPES = ("MODEL",)
    FUNCTION = "patch"
    CATEGORY = "model_patches/attention"
    DESCRIPTION = (
        "MiniMax H3 Sol-RT v3.2. base_rt_overlap pipelines OptiX routing with "
        "INT8 Base-Sol attention on a second CUDA stream. Serial/A-B backends retained."
    )

    def patch(
        self, model, enabled, backend, rt_proof_mode, tau, min_tokens, q_chunk_blocks,
        exact_list_capacity, output_check_calls,
        strict, thresh_type, int8_qk, int8_pv, sink_conditioning,
        dll_path="", log_files=True, log_dir="",
    ):
        if not enabled:
            return (model,)

        diffusion_model = model.get_model_object("diffusion_model")
        blocks = getattr(diffusion_model, "blocks", None)
        if diffusion_model.__class__.__name__ != "MiniMaxH3Model" or blocks is None:
            raise RuntimeError("MiniMaxH3SolRTActivePatch requires MiniMaxH3Model")

        patched = model.clone()
        # v3.0 fix1: always initialize INT8 flags before _make_forward.
        active_int8_qk = bool(int8_qk)
        active_int8_pv = bool(int8_pv)
        # active_rt/compact_rt remain BF16-only. base_rt_split v3.1-INT8
        # intentionally honors the user's Base Sol INT8 settings.
        if str(backend) in ("active_rt", "compact_rt"):
            active_int8_qk = False
            active_int8_pv = False
        _install_span_injector(patched)

        block_count = len(blocks)

        active_router = None
        shadow_validator = None

        if str(backend) in ("base_rt_split", "base_rt_overlap"):
            active_router = BaseRTSplitRouter(
                dll_path=dll_path,
                q_chunk_blocks=int(q_chunk_blocks),
                strict=bool(strict),
                log_files=bool(log_files),
                log_dir=str(log_dir or ""),
                blocks_per_step=block_count,
                proof_mode=str(rt_proof_mode),
            )
        elif str(backend) in ("active_rt", "compact_rt"):
            active_router = SolRTActiveRouter(
                dll_path=dll_path,
                q_chunk_blocks=int(q_chunk_blocks),
                strict=bool(strict),
                log_files=bool(log_files),
                log_dir=str(log_dir or ""),
                blocks_per_step=block_count,
            )
        elif str(backend) == "shadow_validate":
            shadow_validator = SolRTShadowValidator(
                dll_path=dll_path,
                q_chunk_blocks=int(q_chunk_blocks),
                verify_every=1,
                strict=bool(strict),
                max_mismatch=0,
                log_files=bool(log_files),
                log_dir=str(log_dir or ""),
            )

        installed = 0
        for i in range(block_count):
            attn = patched.get_model_object(f"diffusion_model.blocks.{i}.attn")
            path = f"diffusion_model.blocks.{i}.attn.forward"
            prior = getattr(patched, "object_patches", {}).get(path)
            fallback = prior if prior is not None else attn.forward
            if hasattr(fallback, "_minimax_h3_sol_rt_fallback"):
                fallback = fallback._minimax_h3_sol_rt_fallback

            patched.add_object_patch(
                path,
                _make_forward(
                    attn,
                    fallback,
                    block_id=i,
                    backend=str(backend),
                    active_router=active_router,
                    shadow_validator=shadow_validator,
                    tau=float(tau),
                    min_tokens=int(min_tokens),
                    strict=bool(strict),
                    thresh_type=str(thresh_type),
                    sink_conditioning=str(sink_conditioning),
                    int8_qk=active_int8_qk,
                    int8_pv=active_int8_pv,
                    exact_list_capacity=int(exact_list_capacity),
                    output_check_calls=int(output_check_calls),
                ),
            )
            installed += 1

        log.info(
            "[Base-Sol RT] v3.2-INT8-OVERLAP-fix1 patched %d/%d H3 attention blocks; backend=%s "
            "proof_mode=%s tau=%.2f q_chunk_blocks=%d int8_qk=%s int8_pv=%s",
            installed, block_count, backend, str(rt_proof_mode),
            float(tau), int(q_chunk_blocks),
            active_int8_qk, active_int8_pv,
        )
        return (patched,)


NODE_CLASS_MAPPINGS = {
    "MiniMaxH3SolRTActivePatch": MiniMaxH3SolRTActivePatch,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "MiniMaxH3SolRTActivePatch": "MiniMax H3 Base-Sol + RT Split v3.1 INT8 CSR",
}
