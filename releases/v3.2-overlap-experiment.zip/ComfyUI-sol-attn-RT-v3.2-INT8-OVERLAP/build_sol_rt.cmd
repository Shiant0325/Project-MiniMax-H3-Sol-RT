@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0sol_rt_native"

echo [Sol-RT] Building v3.2 async OptiX backend...

where nmake >nul 2>nul
if errorlevel 1 (
  if exist "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" (
    call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64
  ) else (
    echo [ERROR] NMake is not available and VS2022 BuildTools VsDevCmd.bat was not found.
    exit /b 1
  )
)

if exist build rmdir /s /q build

cmake -S . -B build ^
  -G "NMake Makefiles" ^
  -DCMAKE_BUILD_TYPE=Release ^
  -DCMAKE_CUDA_COMPILER="C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.8\bin\nvcc.exe" ^
  -DCMAKE_CUDA_ARCHITECTURES=120 ^
  -DOPTIX_ROOT="C:\ProgramData\NVIDIA Corporation\OptiX SDK 9.1.0"
if errorlevel 1 exit /b 1

cmake --build build
if errorlevel 1 exit /b 1

copy /y "build\sol_rt_router.dll" "sol_rt_router.dll" >nul
copy /y "build\rt_programs.ptx" "rt_programs.ptx" >nul

if not exist "sol_rt_router.dll" (
  echo [ERROR] sol_rt_router.dll was not produced.
  exit /b 1
)

for /f "delims=" %%P in ('where python 2^>nul') do (
  set PY=%%P
  goto :have_python
)
:have_python
if not defined PY (
  echo [WARN] Python not found on PATH; skipping export verification.
  goto :done
)

"%PY%" -c "import ctypes,sys; d=ctypes.WinDLL(r'%CD%\\sol_rt_router.dll'); assert hasattr(d,'sol_rt_route_async'), 'missing sol_rt_route_async'; print('[Sol-RT] VERIFIED export: sol_rt_route_async')"
if errorlevel 1 (
  echo [ERROR] Built DLL still lacks sol_rt_route_async.
  exit /b 1
)

:done
echo.
echo [Sol-RT] Build complete:
echo   %CD%\sol_rt_router.dll
echo   %CD%\rt_programs.ptx
echo Restart ComfyUI before testing base_rt_overlap.
endlocal
