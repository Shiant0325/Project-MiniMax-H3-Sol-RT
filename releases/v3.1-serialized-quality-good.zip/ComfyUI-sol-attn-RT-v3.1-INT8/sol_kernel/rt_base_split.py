"""MiniMax H3 Base-Sol + RT Split v3.0.

This backend starts from the original Base Sol pointer path and changes only
the work scheduling:

- Sol's kc/vc summaries and threshold preparation are unchanged.
- Route scores are computed from q-block centroids:
      mean_i(q_i @ kc) == mean_i(q_i) @ kc
  which is algebraically the same Sol routing expression.
- OptiX RT performs 8-block coarse candidate selection.
- CUDA finalizes exact threshold decisions.
- Local +/-1 and conditioning sink exactness are ORed in unchanged.
- The final exact set is compacted.
- The forward keeps Base Sol's summary approximate pass and performs full
  QK/PV only over compact exact indices.

This is designed to retain Base Sol's optimized arithmetic while removing the
dynamic exact-block discovery/loop from its group traversal.
"""

from __future__ import annotations

import math
import time
import logging

import torch
import triton
import triton.language as tl

from .fwd import _PTR_CONFIGS, _tuned, _round_to_int8
from .rt_router import _NATIVE, RT_GROUP
from .rt_compact import compact_exact_csr

log = logging.getLogger(__name__)

BLOCK = 64
GROUP = 32


@triton.jit
def _centroid_route_scores_kernel(
    q_ptr,
    kc_ptr,
    out_ptr,
    scale_log2,
    T,
    q_block_start,
    q_count,
    sq_b, sq_t, sq_h,
    H: tl.constexpr,
    N: tl.constexpr,
    D: tl.constexpr,
    ROUTE_GROUP: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    kv_group, q_local, bh = (
        tl.program_id(0),
        tl.program_id(1),
        tl.program_id(2),
    )
    if q_local >= q_count:
        return

    batch = bh // H
    head = bh % H
    q_block = q_block_start + q_local
    q_start = q_block * BLOCK_SIZE

    q_rows = q_start + tl.arange(0, BLOCK_SIZE)
    d = tl.arange(0, D)
    qv = tl.load(
        q_ptr
        + batch * sq_b
        + q_rows[:, None].to(tl.int64) * sq_t
        + head * sq_h
        + d[None, :],
        mask=(q_rows < T)[:, None],
        other=0.0,
    )
    q_len = tl.minimum(BLOCK_SIZE, T - q_start).to(tl.float32)
    q_bar = tl.sum(qv.to(tl.float32), axis=0) / q_len

    kv = kv_group * ROUTE_GROUP + tl.arange(0, ROUTE_GROUP)
    valid = kv < N
    kc = tl.load(
        kc_ptr
        + ((batch * N + kv[:, None]) * H + head) * D
        + d[None, :],
        mask=valid[:, None],
        other=0.0,
    )

    # Exact algebraic Sol route score, accumulated from a single centroid vector.
    route = tl.sum(
        q_bar[None, :] * kc.to(tl.float32),
        axis=1,
    ) * scale_log2

    row = bh * q_count + q_local
    tl.store(out_ptr + row * N + kv, route, mask=valid)


def compute_centroid_route_scores(
    q: torch.Tensor,
    kc: torch.Tensor,
    scale: float,
    q_start: int,
    q_count: int,
):
    B, T, H, D = q.shape
    N = kc.shape[1]
    out = torch.empty(
        (B * H * q_count, N),
        device=q.device,
        dtype=torch.float32,
    )
    groups = triton.cdiv(N, RT_GROUP)
    _centroid_route_scores_kernel[(groups, q_count, B * H)](
        q, kc, out,
        float(scale) * 1.4426950408889634,
        T,
        int(q_start),
        int(q_count),
        q.stride(0), q.stride(1), q.stride(2),
        H=H,
        N=N,
        D=D,
        ROUTE_GROUP=RT_GROUP,
        BLOCK_SIZE=BLOCK,
        num_warps=4,
    )
    return out


class BaseRTSplitRouter:
    def __init__(
        self,
        *,
        dll_path="",
        q_chunk_blocks=32,
        strict=True,
        log_files=True,
        log_dir="",
        blocks_per_step=50,
    ):
        from .rt_active import SolRTActiveLogger
        self.dll_path = str(dll_path or "")
        self.q_chunk_blocks = max(1, int(q_chunk_blocks))
        self.strict = bool(strict)
        self.calls = 0
        self.blocks_per_step = int(blocks_per_step)
        self.logger = SolRTActiveLogger(
            enabled=bool(log_files),
            log_dir=str(log_dir or ""),
            blocks_per_step=self.blocks_per_step,
        )
        self._cache = {}

    def _indices(self, device, N, rows_rt, groups):
        key = (device.type, device.index, N, rows_rt, groups)
        hit = self._cache.get(key)
        if hit is not None:
            return hit
        slots = torch.arange(groups, device=device)[None, :]
        row_ids = torch.arange(
            rows_rt, device=device
        )[:, None].expand(rows_rt, groups)
        kv_group = torch.div(
            torch.arange(N, device=device),
            RT_GROUP,
            rounding_mode="floor",
        )
        hit = (slots, row_ids, kv_group)
        self._cache[key] = hit
        return hit

    def build_threshold_mask(self, q, kc, threshold, scale):
        self.calls += 1
        call = self.calls
        B, T, H, D = q.shape
        N = kc.shape[1]
        BH = B * H
        qc_fixed = self.q_chunk_blocks

        _NATIVE.load(self.dll_path)
        full_mask = torch.empty(
            (BH, N, N), device=q.device, dtype=torch.uint8
        )

        score_ms = 0.0
        setup_ms = 0.0
        group_ms = 0.0
        trace_ms = 0.0
        finalize_ms = 0.0
        candidate_groups_total = 0
        exact_blocks_total = 0
        false_neg_total = 0

        wall0 = time.perf_counter()

        for qs in range(0, N, qc_fixed):
            qc = min(qc_fixed, N - qs)

            e0 = torch.cuda.Event(enable_timing=True)
            e1 = torch.cuda.Event(enable_timing=True)
            e0.record()
            scores_actual = compute_centroid_route_scores(
                q, kc, scale, qs, qc
            )
            e1.record()
            e1.synchronize()
            score_ms += e0.elapsed_time(e1)

            th_actual = (
                threshold[:, qs:qs + qc, :]
                .permute(0, 2, 1)
                .contiguous()
                .reshape(BH * qc)
                .to(torch.float32)
            )

            # Pad short tail to persistent RT shape.
            if qc == qc_fixed:
                scores_rt = scores_actual
                th_rt = th_actual
            else:
                scores_rt = torch.full(
                    (BH, qc_fixed, N),
                    -float("inf"),
                    device=q.device,
                    dtype=torch.float32,
                )
                scores_rt[:, :qc, :] = scores_actual.reshape(BH, qc, N)
                scores_rt = scores_rt.reshape(BH * qc_fixed, N)

                th_rt = torch.full(
                    (BH, qc_fixed),
                    float("inf"),
                    device=q.device,
                    dtype=torch.float32,
                )
                th_rt[:, :qc] = th_actual.reshape(BH, qc)
                th_rt = th_rt.reshape(-1)

            rt_groups, rt_counts, timing = _NATIVE.route(scores_rt, th_rt)
            setup_ms += timing["geometry_ms"] + timing["gas_ms"]
            group_ms += timing["group_max_ms"]
            trace_ms += timing["trace_ms"]

            rows_rt, groups = rt_groups.shape
            rt_active = torch.zeros(
                (rows_rt, groups),
                device=q.device,
                dtype=torch.bool,
            )
            slots, row_ids, kv_group = self._indices(
                q.device, N, rows_rt, groups
            )
            valid_slots = slots < rt_counts[:, None].clamp(max=groups)
            vr = row_ids[valid_slots]
            vg = rt_groups[valid_slots]
            ok = (vg >= 0) & (vg < groups)
            rt_active[vr[ok], vg[ok]] = True

            rt_active = (
                rt_active
                .reshape(BH, qc_fixed, groups)[:, :qc, :]
                .reshape(BH * qc, groups)
            )

            f0 = torch.cuda.Event(enable_timing=True)
            f1 = torch.cuda.Event(enable_timing=True)
            f0.record()

            candidate = rt_active[:, kv_group]
            ref_exact = scores_actual > th_actual[:, None]
            active_exact = candidate & ref_exact

            # Because RT selects on the same centroid score matrix, this is an
            # exact zero-false-negative safety check for the active route.
            false_neg = ref_exact & ~candidate
            fn = int(false_neg.sum().item())
            false_neg_total += fn

            candidate_groups_total += int(rt_active.sum().item())
            exact_blocks_total += int(active_exact.sum().item())

            full_mask[:, qs:qs + qc, :] = (
                active_exact.reshape(BH, qc, N).to(torch.uint8)
            )

            f1.record()
            f1.synchronize()
            finalize_ms += f0.elapsed_time(f1)

            if fn:
                raise RuntimeError(
                    f"Base-RT split false negative at q slab "
                    f"{qs}:{qs+qc}: {fn}"
                )

        router_ms = (time.perf_counter() - wall0) * 1000.0
        rows_total = BH * N
        possible_groups = rows_total * math.ceil(N / RT_GROUP)
        possible_blocks = rows_total * N

        metrics = {
            "call": call,
            "step": ((call - 1) // self.blocks_per_step) + 1,
            "tokens": T,
            "heads": H,
            "route_blocks": N,
            "slabs": math.ceil(N / qc_fixed),
            "q_chunk_blocks": qc_fixed,
            "rt_group": RT_GROUP,
            "rows": rows_total,
            "candidate_groups": candidate_groups_total,
            "candidate_group_pct":
                100.0 * candidate_groups_total / max(1, possible_groups),
            "threshold_exact_blocks": exact_blocks_total,
            "threshold_exact_pct":
                100.0 * exact_blocks_total / max(1, possible_blocks),
            "false_negative_blocks": false_neg_total,
            "setup_ms": setup_ms,
            "route_score_ms": score_ms,
            "group_max_ms": group_ms,
            "rt_trace_ms": trace_ms,
            "finalize_ms": finalize_ms,
            "router_total_ms": router_ms,
        }

        log.info(
            "[Base-Sol RT] route call=%d step=%d tokens=%d N=%d slabs=%d "
            "cand=%.2f%% exact=%.2f%% false_neg=%d "
            "centroid=%.2fms rt=%.2fms finalize=%.2fms router=%.2fms",
            call, metrics["step"], T, N, metrics["slabs"],
            metrics["candidate_group_pct"],
            metrics["threshold_exact_pct"],
            false_neg_total,
            score_ms, trace_ms, finalize_ms, router_ms,
        )
        return full_mask, metrics


@_tuned(_PTR_CONFIGS)
@triton.jit
def _forward_base_rt_split(
    q_ptr, k_ptr, v_ptr,
    kc_ptr, vc_ptr,
    exact_mask_ptr,
    exact_offsets_ptr, exact_idx_ptr,
    o_ptr,
    scale,
    max_exact_runtime,
    T,
    sq_b, sq_t, sq_h,
    sk_b, sk_t, sk_h,
    sv_b, sv_t, sv_h,
    H: tl.constexpr,
    D: tl.constexpr,
    NT: tl.constexpr,
    BV: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    GROUP_SIZE: tl.constexpr,
):
    """Base-Sol arithmetic with RT split scheduling.

    Approximate path remains the same centroid-softmax computation over all
    non-exact blocks. Full-resolution K/V work is moved to one compact exact loop.
    """
    v_tile, q_block, batch_head = (
        tl.program_id(0), tl.program_id(1), tl.program_id(2)
    )
    batch, head = batch_head // H, batch_head % H
    group_offsets = tl.max_contiguous(
        tl.arange(0, GROUP_SIZE), GROUP_SIZE
    )
    token_offsets = tl.max_contiguous(
        tl.arange(0, BLOCK_SIZE), BLOCK_SIZE
    )
    d_offsets = tl.arange(0, D)
    bv_offsets = v_tile * BV + tl.arange(0, BV)

    q_start = q_block * BLOCK_SIZE
    q_rows = q_start + token_offsets
    q_valid = q_rows < T

    q = tl.load(
        q_ptr
        + batch * sq_b
        + q_rows[:, None].to(tl.int64) * sq_t
        + head * sq_h
        + d_offsets[None, :],
        mask=q_valid[:, None],
        other=0.0,
    )

    output = tl.zeros([BLOCK_SIZE, BV], dtype=tl.float32)
    row_sum = tl.zeros((BLOCK_SIZE,), dtype=tl.float32)
    row_max = tl.full(
        (BLOCK_SIZE,), -float("inf"), tl.float32
    )
    scale_log2 = scale * 1.4426950408889634
    tail_length = T - (NT - 1) * BLOCK_SIZE
    mask_row = (batch_head * NT + q_block) * NT

    # Base-Sol summary pass, now without threshold reduction or dynamic
    # exact-block discovery inside each group.
    for group_start in range(0, NT, GROUP_SIZE):
        block_indices = group_start + group_offsets
        valid = block_indices < NT

        kc = tl.load(
            kc_ptr
            + ((batch * NT + block_indices[:, None]) * H + head) * D
            + d_offsets[None, :],
            mask=valid[:, None],
            other=0.0,
        )
        vc = tl.load(
            vc_ptr
            + ((batch * NT + block_indices[:, None]) * H + head) * D
            + bv_offsets[None, :],
            mask=valid[:, None],
            other=0.0,
        )
        scores = tl.dot(q, kc.T).to(tl.float32) * scale_log2

        exact = (
            tl.load(
                exact_mask_ptr + mask_row + block_indices,
                mask=valid,
                other=0,
            ) != 0
        )
        approximate = valid & ~exact

        approximate_scores = tl.where(
            approximate[None, :],
            scores,
            -float("inf"),
        )
        new_max = tl.maximum(
            row_max,
            tl.max(approximate_scores, axis=1),
        )
        alpha = tl.math.exp2(
            tl.where(
                row_max == new_max,
                0.0,
                row_max - new_max,
            )
        )
        probability = tl.where(
            approximate[None, :],
            tl.math.exp2(
                approximate_scores - new_max[:, None]
            ),
            0.0,
        )

        output = output * alpha[:, None] + tl.dot(
            probability.to(vc.dtype), vc
        )
        lengths = tl.where(
            block_indices == NT - 1,
            tail_length,
            BLOCK_SIZE,
        ).to(tl.float32)
        row_sum = row_sum * alpha + tl.sum(
            probability * lengths[None, :],
            axis=1,
        )
        row_max = new_max

    # Compact exact QK/PV loop.
    list_row = batch_head * NT + q_block
    row_start = tl.load(exact_offsets_ptr + list_row)
    row_end = tl.load(exact_offsets_ptr + list_row + 1)
    exact_count = row_end - row_start
    loop_end = tl.minimum(exact_count, max_exact_runtime)

    for slot in tl.range(0, loop_end, num_stages=1):
        block = tl.load(
            exact_idx_ptr + row_start + slot
        ).to(tl.int32)
        kv_start = block * BLOCK_SIZE
        k_rows = kv_start + token_offsets
        k_valid = k_rows < T

        kb = tl.load(
            k_ptr
            + batch * sk_b
            + k_rows[:, None].to(tl.int64) * sk_t
            + head * sk_h
            + d_offsets[None, :],
            mask=k_valid[:, None],
            other=0.0,
        )

        exact_scores = (
            tl.dot(q, kb.T).to(tl.float32) * scale_log2
        )
        exact_scores += tl.where(
            k_valid[None, :],
            0.0,
            -float("inf"),
        )

        new_max = tl.maximum(
            row_max,
            tl.max(exact_scores, axis=1),
        )
        alpha = tl.math.exp2(row_max - new_max)
        p = tl.math.exp2(
            exact_scores - new_max[:, None]
        )
        row_sum = row_sum * alpha + tl.sum(p, axis=1)

        vb = tl.load(
            v_ptr
            + batch * sv_b
            + k_rows[:, None].to(tl.int64) * sv_t
            + head * sv_h
            + bv_offsets[None, :],
            mask=k_valid[:, None],
            other=0.0,
        )
        output = output * alpha[:, None] + tl.dot(
            p.to(vb.dtype), vb
        )
        row_max = new_max

    tl.store(
        o_ptr
        + ((batch * T + q_rows[:, None]) * H + head) * D
        + bv_offsets[None, :],
        (output / row_sum[:, None]).to(tl.bfloat16),
        mask=q_valid[:, None],
    )


@_tuned(_PTR_CONFIGS)
@triton.jit
def _forward_base_rt_split_int8(
    q_ptr, v_ptr,
    kc_ptr, vc_ptr,
    qi_ptr, ki_ptr,
    q_scale_ptr, k_scale_ptr,
    vi_ptr, vsc_ptr,
    exact_mask_ptr,
    exact_offsets_ptr, exact_idx_ptr,
    o_ptr,
    scale,
    max_exact_runtime,
    T,
    sq_b, sq_t, sq_h,
    sv_b, sv_t, sv_h,
    H: tl.constexpr,
    D: tl.constexpr,
    NT: tl.constexpr,
    BV: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    GROUP_SIZE: tl.constexpr,
    INT8_PV: tl.constexpr,
):
    """Base-Sol INT8 QK/PV arithmetic with RT+CSR exact scheduling.

    Q/K residual dot follows Base Sol:
      exact_score = int8(q_residual) dot int8(k_residual) * scales
                    + BF16 q dot kc(block)

    With INT8_PV, the exact probability/V product follows Base Sol's
    probability int8 quantization and per-channel V scaling.
    """
    v_tile, q_block, batch_head = (
        tl.program_id(0), tl.program_id(1), tl.program_id(2)
    )
    batch, head = batch_head // H, batch_head % H

    group_offsets = tl.max_contiguous(
        tl.arange(0, GROUP_SIZE), GROUP_SIZE
    )
    token_offsets = tl.max_contiguous(
        tl.arange(0, BLOCK_SIZE), BLOCK_SIZE
    )
    d_offsets = tl.arange(0, D)
    bv_offsets = v_tile * BV + tl.arange(0, BV)

    q_start = q_block * BLOCK_SIZE
    q_rows = q_start + token_offsets
    q_valid = q_rows < T

    q = tl.load(
        q_ptr
        + batch * sq_b
        + q_rows[:, None].to(tl.int64) * sq_t
        + head * sq_h
        + d_offsets[None, :],
        mask=q_valid[:, None],
        other=0.0,
    )

    qi = tl.load(
        qi_ptr
        + ((batch * T + q_rows[:, None]) * H + head) * D
        + d_offsets[None, :],
        mask=q_valid[:, None],
        other=0,
    )
    qs = tl.load(
        q_scale_ptr + (batch * T + q_rows) * H + head,
        mask=q_valid,
        other=1.0,
    )

    if INT8_PV:
        v_scale = tl.load(
            vsc_ptr + batch_head * D + bv_offsets
        )

    output = tl.zeros([BLOCK_SIZE, BV], dtype=tl.float32)
    row_sum = tl.zeros((BLOCK_SIZE,), dtype=tl.float32)
    row_max = tl.full((BLOCK_SIZE,), -float("inf"), tl.float32)

    scale_log2 = scale * 1.4426950408889634
    tail_length = T - (NT - 1) * BLOCK_SIZE
    mask_row = (batch_head * NT + q_block) * NT

    # --------------------------------------------------------
    # Base-Sol summary approximate path.
    # --------------------------------------------------------
    for group_start in range(0, NT, GROUP_SIZE):
        block_indices = group_start + group_offsets
        valid = block_indices < NT

        kc = tl.load(
            kc_ptr
            + ((batch * NT + block_indices[:, None]) * H + head) * D
            + d_offsets[None, :],
            mask=valid[:, None],
            other=0.0,
        )
        vc = tl.load(
            vc_ptr
            + ((batch * NT + block_indices[:, None]) * H + head) * D
            + bv_offsets[None, :],
            mask=valid[:, None],
            other=0.0,
        )

        scores = tl.dot(q, kc.T).to(tl.float32) * scale_log2

        exact = (
            tl.load(
                exact_mask_ptr + mask_row + block_indices,
                mask=valid,
                other=0,
            ) != 0
        )
        approximate = valid & ~exact

        approximate_scores = tl.where(
            approximate[None, :], scores, -float("inf")
        )
        new_max = tl.maximum(
            row_max, tl.max(approximate_scores, axis=1)
        )
        alpha = tl.math.exp2(
            tl.where(
                row_max == new_max,
                0.0,
                row_max - new_max,
            )
        )
        probability = tl.where(
            approximate[None, :],
            tl.math.exp2(
                approximate_scores - new_max[:, None]
            ),
            0.0,
        )

        output = output * alpha[:, None] + tl.dot(
            probability.to(vc.dtype), vc
        )

        lengths = tl.where(
            block_indices == NT - 1,
            tail_length,
            BLOCK_SIZE,
        ).to(tl.float32)
        row_sum = row_sum * alpha + tl.sum(
            probability * lengths[None, :], axis=1
        )
        row_max = new_max

    # --------------------------------------------------------
    # CSR exact path with Base Sol INT8 residual QK and PV.
    # --------------------------------------------------------
    list_row = batch_head * NT + q_block
    row_start = tl.load(exact_offsets_ptr + list_row)
    row_end = tl.load(exact_offsets_ptr + list_row + 1)
    exact_count = row_end - row_start
    loop_end = tl.minimum(exact_count, max_exact_runtime)

    for slot in tl.range(0, loop_end, num_stages=1):
        block = tl.load(
            exact_idx_ptr + row_start + slot
        ).to(tl.int32)

        kv_start = block * BLOCK_SIZE
        k_rows = kv_start + token_offsets
        k_valid = k_rows < T

        ki = tl.load(
            ki_ptr
            + ((batch * T + k_rows[:, None]) * H + head) * D
            + d_offsets[None, :],
            mask=k_valid[:, None],
            other=0,
        )
        ks = tl.load(
            k_scale_ptr + (batch * T + k_rows) * H + head,
            mask=k_valid,
            other=1.0,
        )

        # INT8 residual term.
        s32 = tl.dot(qi, ki.T, out_dtype=tl.int32)

        # BF16 block mean term; same term Base Sol calls approx_col.
        kc_block = tl.load(
            kc_ptr
            + ((batch * NT + block) * H + head) * D
            + d_offsets,
        )
        mean_term = tl.sum(
            q.to(tl.float32) * kc_block[None, :].to(tl.float32),
            axis=1,
        ) * scale_log2

        exact_scores = (
            s32.to(tl.float32)
            * (qs[:, None] * ks[None, :])
            * scale_log2
            + mean_term[:, None]
        )
        exact_scores += tl.where(
            k_valid[None, :], 0.0, -float("inf")
        )

        block_max = tl.max(exact_scores, axis=1)
        new_max = tl.maximum(row_max, block_max)
        alpha = tl.math.exp2(row_max - new_max)

        if INT8_PV:
            vi = tl.load(
                vi_ptr
                + ((batch * T + k_rows[:, None]) * H + head) * D
                + bv_offsets[None, :],
                mask=k_valid[:, None],
                other=0,
            )

            pe = tl.math.exp2(
                exact_scores - block_max[:, None]
            )
            beta = tl.math.exp2(block_max - new_max)

            row_sum = (
                row_sum * alpha
                + beta * tl.sum(pe, axis=1)
            )

            pi = tl.minimum(
                pe * 127.0 + 0.5, 127.0
            ).to(tl.int8)

            pv = tl.dot(
                pi, vi, out_dtype=tl.int32
            ).to(tl.float32) * (
                (beta * (1.0 / 127.0))[:, None]
                * v_scale[None, :]
            )

            output = output * alpha[:, None] + pv
        else:
            p = tl.math.exp2(
                exact_scores - new_max[:, None]
            )
            row_sum = row_sum * alpha + tl.sum(p, axis=1)

            vb = tl.load(
                v_ptr
                + batch * sv_b
                + k_rows[:, None].to(tl.int64) * sv_t
                + head * sv_h
                + bv_offsets[None, :],
                mask=k_valid[:, None],
                other=0.0,
            )

            output = output * alpha[:, None] + tl.dot(
                p.to(vb.dtype), vb
            )

        row_max = new_max

    tl.store(
        o_ptr
        + ((batch * T + q_rows[:, None]) * H + head) * D
        + bv_offsets[None, :],
        (output / row_sum[:, None]).to(tl.bfloat16),
        mask=q_valid[:, None],
    )


__all__ = [
    "BaseRTSplitRouter",
    "compute_centroid_route_scores",
    "_forward_base_rt_split",
    "_forward_base_rt_split_int8",
]
