# MiniMax H3 Base-Sol + RT Split v3.1 INT8 CSR

This build makes the RT split backend honor the same precision toggles as the
original Base Sol benchmark:

    int8_qk = true
    int8_pv = true

The previous v3.1 CSR build forced base_rt_split to BF16, so its speed could not
be compared fairly against the user's ~104.33 s/step Base Sol INT8 baseline.

## Exact path

For exact blocks:

    score =
      INT8(Q residual) dot INT8(K residual) * q_scale * k_scale
      + BF16 Q dot block-mean(K)

When int8_pv=true:

    P is quantized to int8 per exact block
    V is per-channel int8
    PV uses int32 dot + Base Sol scaling

This mirrors Base Sol's INT8 exact arithmetic while RT+CSR supplies the exact
block schedule.

## Recommended comparison run

    backend              = base_rt_split
    tau                  = 1.30
    min_tokens           = 4096
    q_chunk_blocks       = 32
    output_check_calls   = 1
    strict               = true
    thresh_type          = diag
    int8_qk              = true
    int8_pv              = true
    sink_conditioning    = exact_kv
    log_files            = true

The first output check now compares against Base Sol with BOTH INT8 toggles on.

After correctness validation:

    output_check_calls = 0

for the clean timing run.

## Note

This first INT8 RT-split version uses Base Sol's materialized Q-int8/scale
producer for routing compatibility. Original long-context Base Sol can use its
inline-Q optimization. If this build validates, moving Q quantization and
threshold production inline is the next straightforward overhead removal.
