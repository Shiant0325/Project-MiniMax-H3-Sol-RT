@echo off
setlocal
echo This package already includes the native DLL/PTX when present in the ZIP.
echo If they are missing, copy your proven v1 files into:
echo   sol_rt_native\sol_rt_router.dll
echo   sol_rt_native\rt_programs.ptx
echo.
dir /b sol_rt_native\sol_rt_router.dll 2>nul
dir /b sol_rt_native\rt_programs.ptx 2>nul
