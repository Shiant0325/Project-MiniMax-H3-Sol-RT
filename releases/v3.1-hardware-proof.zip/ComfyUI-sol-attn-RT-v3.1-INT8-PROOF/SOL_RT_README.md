# MiniMax H3 Sol-RT v1 — all-block shadow integration

This build is based directly on the supplied `ComfyUI-sol-attn` source.

## What v1 does

For every patched MiniMax H3 attention block:

1. Uses Sol's original BF16 K block summaries and threshold calculation.
2. Recomputes the routing score in a Triton kernel with the same expression used by Sol:
   `mean(Q_block @ K_centroid) * scale_log2`.
3. Groups 8 consecutive KV blocks.
4. CUDA computes each group's exact maximum routing score.
5. OptiX / RT cores traverse the persistent group geometry and keep groups whose
   max score exceeds the exact Sol threshold.
6. The RT group set is compared against a CUDA reference.
7. The ORIGINAL Sol pointer forward produces the model output.

Therefore v1 is a real RT-core integration but intentionally does not yet allow
the RT path to change model output.

## Why shadow first

The old experimental H3 sparse patch lost quality when multiple blocks were
patched. This build requires zero RT/CUDA routing mismatches on real generations
before routing is allowed to control attention.

## Scope

- MiniMax H3
- SM120 / RTX 50-series
- BF16 Sol path
- all transformer blocks (normally 50)
- Sol BLOCK=64 unchanged
- Sol threshold/tau unchanged
- conditioning sink rules unchanged
- no M3/MSA Top-K logic

INT8 Sol paths are intentionally not part of v1.

## Install

Put the whole folder under:

    ComfyUI/custom_nodes/ComfyUI-sol-attn-RT-v1

Do not keep another copy of the original Sol custom node enabled at the same
time during the first test, because this fork already contains it.

## Build native RT backend

Open the Visual Studio x64 Developer Command Prompt and run:

    cd /d <this folder>
    build_sol_rt.cmd

Expected:
    sol_rt_native\build\sol_rt_router.dll
    sol_rt_native\build\rt_programs.ptx

## ComfyUI node

Use:

    MiniMax H3 Sol-RT Shadow (All Blocks)

Recommended first run:
- tau: same value as your known-good Sol workflow
- min_tokens: 4096
- q_chunk_blocks: 8
- verify_every: 1
- strict: true
- thresh_type: diag
- sink_conditioning: exact_kv

Console should report:

    [Sol-RT] SHADOW patched 50/50 H3 attention blocks
    [Sol-RT] real H3 shadow active: ...
    [Sol-RT] shadow call=... mismatches=0 ...

Any nonzero mismatch is a blocker for activating RT routing.

## Performance note

Shadow mode intentionally performs extra routing work, so it will be slower than
normal Sol. Its purpose is correctness validation on the real model.

After zero-mismatch validation, v2 can make the RT-generated route set active and
benchmark whether the split is worthwhile at 65k, 100k and 200k tokens.


## Automatic log files

The RT node now writes one directory per ComfyUI run/session when `log_files=true`.

Default location:

    ComfyUI/output/sol_rt_logs/session_YYYYMMDD_HHMMSS/

Files:

- `sol_rt_calls.jsonl` — complete machine-readable record per attention call
- `sol_rt_calls.csv` — spreadsheet-friendly benchmark data
- `summary.txt` — continuously updated cumulative totals

Recorded fields include:
- call number
- token count / heads / route blocks
- q_chunk_blocks / RT group size
- total routed rows
- mismatches
- one-time setup/GAS time
- summed CUDA group-max time across all slabs
- maximum group-max slab time
- summed RT trace time across all slabs
- maximum RT trace slab time

The summary file updates after every call, so it remains useful even if ComfyUI
is interrupted before generation completes.
