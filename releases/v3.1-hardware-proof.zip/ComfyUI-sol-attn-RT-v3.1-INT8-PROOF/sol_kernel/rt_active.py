"""Active OptiX routing backend for MiniMax H3 Sol-Attn.

v2.0 contract
-------------
RT cores actively generate the candidate-group set used by the real Sol forward.
CUDA performs the exact per-block threshold finalization inside those groups.
The resulting threshold-route mask drives which blocks take Sol's full exact QK/PV path.

Sol's locality and conditioning-sink rules remain inside the attention kernel and
therefore cannot be pruned by RT.

This first active build deliberately keeps Sol's approximate/exact arithmetic
unchanged. The goal is active correctness + measurement before deeper kernel fusion.
"""

from __future__ import annotations

import csv
import json
import logging
import math
import threading
import time
from datetime import datetime
from pathlib import Path

import torch
import triton
import triton.language as tl

from .fwd import _PTR_CONFIGS, _tuned
from .rt_router import _NATIVE, compute_route_scores, RT_GROUP

log = logging.getLogger(__name__)

SOL_BLOCK = 64
SOL_GROUP = 32


class SolRTActiveError(RuntimeError):
    pass


class SolRTActiveLogger:
    FIELDS = [
        "timestamp", "call", "step", "block_id",
        "tokens", "heads", "route_blocks", "slabs",
        "q_chunk_blocks", "rt_group",
        "rows", "candidate_groups", "candidate_group_pct",
        "threshold_exact_blocks", "threshold_exact_pct",
        "false_negative_blocks",
        "setup_ms", "route_score_ms",
        "group_max_ms", "rt_trace_ms",
        "finalize_ms", "router_total_ms",
        "compact_ms", "max_exact_per_row", "total_exact_indices",
        "attention_ms", "call_total_ms",
        "output_check_max_abs", "output_check_mean_abs", "output_check_exact_pct",
        "fallback", "backend", "int8_qk", "int8_pv",
    ]

    def __init__(self, enabled=True, log_dir="", blocks_per_step=50):
        self.enabled = bool(enabled)
        self.blocks_per_step = int(blocks_per_step)
        self.lock = threading.Lock()
        self.records = 0
        self.total_router_ms = 0.0
        self.total_attention_ms = 0.0
        self.total_call_ms = 0.0
        self.total_false_negatives = 0
        self.total_candidate_groups = 0
        self.total_exact_blocks = 0
        self.fallbacks = 0

        if not self.enabled:
            self.session_dir = None
            return

        if log_dir:
            base = Path(log_dir).expanduser()
        else:
            # <ComfyUI>/custom_nodes/<node>/sol_kernel/rt_active.py -> <ComfyUI>
            base = Path(__file__).resolve().parents[3] / "output" / "sol_rt_logs"

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.session_dir = base / f"active_{stamp}"
        self.session_dir.mkdir(parents=True, exist_ok=True)
        self.jsonl = self.session_dir / "sol_rt_active_calls.jsonl"
        self.csv = self.session_dir / "sol_rt_active_calls.csv"
        self.summary = self.session_dir / "summary.txt"

        with self.csv.open("w", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, fieldnames=self.FIELDS).writeheader()
        self._write_summary()
        log.info("[Sol-RT] ACTIVE log session: %s", self.session_dir)

    def record(self, rec):
        if not self.enabled:
            return
        row = {k: rec.get(k, "") for k in self.FIELDS}
        with self.lock:
            with self.jsonl.open("a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            with self.csv.open("a", newline="", encoding="utf-8") as f:
                csv.DictWriter(f, fieldnames=self.FIELDS).writerow(row)

            self.records += 1
            self.total_router_ms += float(rec.get("router_total_ms", 0.0))
            self.total_attention_ms += float(rec.get("attention_ms", 0.0))
            self.total_call_ms += float(rec.get("call_total_ms", 0.0))
            self.total_false_negatives += int(rec.get("false_negative_blocks", 0))
            self.total_candidate_groups += int(rec.get("candidate_groups", 0))
            self.total_exact_blocks += int(rec.get("threshold_exact_blocks", 0))
            self.fallbacks += int(bool(rec.get("fallback", False)))
            self._write_summary()

    def _write_summary(self):
        if not self.enabled:
            return
        self.summary.write_text(
            "MiniMax H3 Sol-RT v2 ACTIVE summary\n"
            "===================================\n"
            f"session_dir: {self.session_dir}\n"
            f"records: {self.records}\n"
            f"fallbacks: {self.fallbacks}\n"
            f"total_false_negative_blocks: {self.total_false_negatives}\n"
            f"total_candidate_groups: {self.total_candidate_groups}\n"
            f"total_threshold_exact_blocks: {self.total_exact_blocks}\n"
            f"total_router_ms: {self.total_router_ms:.6f}\n"
            f"total_attention_ms: {self.total_attention_ms:.6f}\n"
            f"total_call_ms: {self.total_call_ms:.6f}\n",
            encoding="utf-8",
        )


class SolRTActiveRouter:
    """Build the RT-controlled threshold-route mask in fixed-size q slabs."""

    def __init__(
        self,
        *,
        dll_path="",
        q_chunk_blocks=8,
        strict=True,
        log_files=True,
        log_dir="",
        blocks_per_step=50,
    ):
        self.dll_path = str(dll_path or "")
        self.q_chunk_blocks = max(1, int(q_chunk_blocks))
        self.strict = bool(strict)
        self.calls = 0
        self.logger = SolRTActiveLogger(
            enabled=log_files,
            log_dir=log_dir,
            blocks_per_step=blocks_per_step,
        )
        self.blocks_per_step = int(blocks_per_step)
        self._last_metrics = None
        self._index_cache = {}

    @staticmethod
    def _event_pair():
        return torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)

    def _cached_indices(self, device, N, rows_rt, groups):
        """Cache tensors that depend only on geometry, not model activations."""
        key = (device.type, device.index, int(N), int(rows_rt), int(groups))
        hit = self._index_cache.get(key)
        if hit is not None:
            return hit
        slots = torch.arange(groups, device=device)[None, :]
        row_ids = torch.arange(rows_rt, device=device)[:, None].expand(rows_rt, groups)
        kv_group = torch.div(
            torch.arange(N, device=device),
            RT_GROUP,
            rounding_mode="floor",
        )
        hit = (slots, row_ids, kv_group)
        self._index_cache[key] = hit
        return hit

    def build_route_mask(self, q, kc, threshold, scale):
        """Return [B*H, N, N] uint8 threshold-route mask.

        RT controls which 8-block groups are candidates. CUDA only finalizes blocks
        inside those RT-returned groups. A false-negative check is always performed
        because any RT false negative would alter Sol semantics.
        """
        self.calls += 1
        call = self.calls
        B, T, H, D = q.shape
        N = kc.shape[1]
        BH = B * H
        qc_fixed = self.q_chunk_blocks

        _NATIVE.load(self.dll_path)

        full_mask = torch.empty((BH, N, N), device=q.device, dtype=torch.uint8)

        route_score_ms = 0.0
        group_max_ms = 0.0
        trace_ms = 0.0
        setup_ms = 0.0
        finalize_ms = 0.0
        candidate_groups_total = 0
        exact_blocks_total = 0
        false_neg_total = 0
        rows_total = BH * N

        router_wall0 = time.perf_counter()

        for qs in range(0, N, qc_fixed):
            qc = min(qc_fixed, N - qs)

            ev0, ev1 = self._event_pair()
            ev0.record()
            scores_actual = compute_route_scores(q, kc, scale, qs, qc)
            ev1.record()
            ev1.synchronize()
            route_score_ms += ev0.elapsed_time(ev1)

            th_actual = (
                threshold[:, qs:qs + qc, :]
                .permute(0, 2, 1)
                .contiguous()
                .reshape(BH, qc)
                .reshape(-1)
                .to(torch.float32)
            )

            # Keep RT GAS shape fixed even for a short tail slab.
            if qc == qc_fixed:
                scores_rt = scores_actual
                th_rt = th_actual
            else:
                scores_rt = torch.full(
                    (BH, qc_fixed, N),
                    -float("inf"),
                    device=q.device,
                    dtype=torch.float32,
                )
                scores_rt[:, :qc, :] = scores_actual.reshape(BH, qc, N)
                scores_rt = scores_rt.reshape(BH * qc_fixed, N)

                th_rt = torch.full(
                    (BH, qc_fixed),
                    float("inf"),
                    device=q.device,
                    dtype=torch.float32,
                )
                th_rt[:, :qc] = th_actual.reshape(BH, qc)
                th_rt = th_rt.reshape(-1)

            rt_groups, rt_counts, timing = _NATIVE.route(scores_rt, th_rt)
            setup_ms += timing["geometry_ms"] + timing["gas_ms"]
            group_max_ms += timing["group_max_ms"]
            trace_ms += timing["trace_ms"]

            # Dense group presence from RT's compact list. Only slots below count
            # are valid; unused output entries are never allowed to clear a true bit.
            rows_rt, groups = rt_groups.shape
            rt_active = torch.zeros((rows_rt, groups), device=q.device, dtype=torch.bool)
            slots, row_ids, kv_group = self._cached_indices(
                q.device, N, rows_rt, groups
            )
            valid_slots = slots < rt_counts[:, None].clamp(max=groups)
            vr = row_ids[valid_slots]
            vg = rt_groups[valid_slots]
            valid_index = (vg >= 0) & (vg < groups)
            rt_active[vr[valid_index], vg[valid_index]] = True

            # Crop padded tail rows back to actual (BH,qc) row order.
            rt_active = rt_active.reshape(BH, qc_fixed, groups)[:, :qc, :].reshape(BH * qc, groups)

            f0, f1 = self._event_pair()
            f0.record()

            candidate = rt_active[:, kv_group]

            # Exact per-block finalization *inside RT-selected groups only*.
            ref_threshold = scores_actual > th_actual[:, None]
            active_exact = candidate & ref_threshold

            # Safety invariant: RT may return extra groups without changing output,
            # but it must never miss a group containing a threshold-exact block.
            false_neg = ref_threshold & ~candidate
            fn = int(false_neg.sum().item())
            false_neg_total += fn

            candidate_groups_total += int(rt_active.sum().item())
            exact_blocks_total += int(active_exact.sum().item())

            full_mask[:, qs:qs + qc, :] = (
                active_exact.reshape(BH, qc, N).to(torch.uint8)
            )

            f1.record()
            f1.synchronize()
            finalize_ms += f0.elapsed_time(f1)

            if fn:
                msg = (
                    f"RT false-negative routing at q-block slab {qs}:{qs+qc}: "
                    f"{fn} threshold-exact blocks were missed"
                )
                if self.strict:
                    raise SolRTActiveError(msg)
                raise SolRTActiveError(msg)

        router_total_ms = (time.perf_counter() - router_wall0) * 1000.0
        possible_groups = rows_total * math.ceil(N / RT_GROUP)
        possible_blocks = rows_total * N

        metrics = {
            "call": call,
            "slabs": math.ceil(N / qc_fixed),
            "step": ((call - 1) // self.blocks_per_step) + 1,
            "tokens": T,
            "heads": H,
            "route_blocks": N,
            "q_chunk_blocks": qc_fixed,
            "rt_group": RT_GROUP,
            "rows": rows_total,
            "candidate_groups": candidate_groups_total,
            "candidate_group_pct": 100.0 * candidate_groups_total / max(1, possible_groups),
            "threshold_exact_blocks": exact_blocks_total,
            "threshold_exact_pct": 100.0 * exact_blocks_total / max(1, possible_blocks),
            "false_negative_blocks": false_neg_total,
            "setup_ms": setup_ms,
            "route_score_ms": route_score_ms,
            "group_max_ms": group_max_ms,
            "rt_trace_ms": trace_ms,
            "finalize_ms": finalize_ms,
            "router_total_ms": router_total_ms,
        }
        self._last_metrics = metrics

        log.info(
            "[Sol-RT] ACTIVE route call=%d step=%d tokens=%d N=%d slabs=%d "
            "cand=%.2f%% exact=%.2f%% false_neg=%d "
            "score=%.2fms rt=%.2fms finalize=%.2fms router=%.2fms",
            call, metrics["step"], T, N, metrics["slabs"],
            metrics["candidate_group_pct"], metrics["threshold_exact_pct"],
            false_neg_total, route_score_ms, trace_ms, finalize_ms, router_total_ms,
        )
        return full_mask, metrics


@_tuned(_PTR_CONFIGS)
@triton.jit
def _forward_ptr_rt_active(
    q_ptr, k_ptr, v_ptr, kc_ptr, vc_ptr, route_mask_ptr, o_ptr,
    scale,
    sink_start,
    sink_end,
    sink_q_start,
    sink_q_end,
    T,
    sq_b, sq_t, sq_h,
    sk_b, sk_t, sk_h,
    sv_b, sv_t, sv_h,
    H: tl.constexpr,
    D: tl.constexpr,
    NT: tl.constexpr,
    BV: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    GROUP_SIZE: tl.constexpr,
):
    """Original Sol pointer forward with threshold routing supplied by RT mask.

    Approximate and exact attention arithmetic is otherwise unchanged.
    Local ±1 blocks, sink KV blocks and sink query rows remain forced exact.
    """
    v_tile, q_block, batch_head = (
        tl.program_id(0), tl.program_id(1), tl.program_id(2)
    )
    batch, head = batch_head // H, batch_head % H
    group_offsets = tl.max_contiguous(tl.arange(0, GROUP_SIZE), GROUP_SIZE)
    token_offsets = tl.max_contiguous(tl.arange(0, BLOCK_SIZE), BLOCK_SIZE)
    d_offsets = tl.arange(0, D)
    bv_offsets = v_tile * BV + tl.arange(0, BV)

    q_start = q_block * BLOCK_SIZE
    q_rows = q_start + token_offsets
    q = tl.load(
        q_ptr + batch * sq_b
        + q_rows[:, None].to(tl.int64) * sq_t
        + head * sq_h
        + d_offsets[None, :],
        mask=(q_rows < T)[:, None],
        other=0.0,
    )

    output = tl.zeros([BLOCK_SIZE, BV], dtype=tl.float32)
    row_sum = tl.zeros((BLOCK_SIZE,), dtype=tl.float32)
    row_max = tl.full((BLOCK_SIZE,), -float("inf"), tl.float32)
    scale_log2 = scale * 1.4426950408889634
    tail_length = T - (NT - 1) * BLOCK_SIZE
    q_in_sink = (q_block >= sink_q_start) & (q_block < sink_q_end)

    # route_mask layout = [B*H, q_block, kv_block]
    route_row = ((batch * H + head) * NT + q_block) * NT

    for group_start in range(0, NT, GROUP_SIZE):
        block_indices = group_start + group_offsets
        valid = block_indices < NT

        kc = tl.load(
            kc_ptr + ((batch * NT + block_indices[:, None]) * H + head) * D
            + d_offsets[None, :],
            mask=valid[:, None],
            other=0.0,
        )
        vc = tl.load(
            vc_ptr + ((batch * NT + block_indices[:, None]) * H + head) * D
            + bv_offsets[None, :],
            mask=valid[:, None],
            other=0.0,
        )

        scores = tl.dot(q, kc.T).to(tl.float32) * scale_log2

        rt_routed = (
            tl.load(
                route_mask_ptr + route_row + block_indices,
                mask=valid,
                other=0,
            ) != 0
        )
        sink_kv = (block_indices >= sink_start) & (block_indices < sink_end)
        routed = (
            rt_routed
            | (tl.abs(q_block - block_indices) <= 1)
            | sink_kv
        ) & valid
        exact = tl.where(q_in_sink, valid, routed)

        approximate = valid & ~exact
        approximate_scores = tl.where(
            approximate[None, :], scores, -float("inf")
        )
        new_max = tl.maximum(row_max, tl.max(approximate_scores, axis=1))
        alpha = tl.math.exp2(
            tl.where(row_max == new_max, 0.0, row_max - new_max)
        )
        approximate_probability = tl.where(
            approximate[None, :],
            tl.math.exp2(approximate_scores - new_max[:, None]),
            0.0,
        )
        output = output * alpha[:, None] + tl.dot(
            approximate_probability.to(vc.dtype), vc
        )
        lengths = tl.where(
            block_indices == NT - 1, tail_length, BLOCK_SIZE
        ).to(tl.float32)
        row_sum = row_sum * alpha + tl.sum(
            approximate_probability * lengths[None, :], axis=1
        )
        row_max = new_max

        exact_offsets = tl.where(exact, group_offsets, GROUP_SIZE)
        for _ in range(tl.sum(exact.to(tl.int32))):
            offset = tl.min(exact_offsets)
            block = group_start + offset
            exact_offsets = tl.where(
                group_offsets == offset, GROUP_SIZE, exact_offsets
            )

            kv_start = block * BLOCK_SIZE
            k_rows = kv_start + token_offsets
            k = tl.load(
                k_ptr + batch * sk_b
                + k_rows[:, None].to(tl.int64) * sk_t
                + head * sk_h
                + d_offsets[None, :],
                mask=(k_rows < T)[:, None],
                other=0.0,
            )
            exact_scores = tl.dot(q, k.T).to(tl.float32) * scale_log2
            exact_scores += tl.where(
                (k_rows < T)[None, :], 0.0, -float("inf")
            )
            new_max = tl.maximum(row_max, tl.max(exact_scores, axis=1))
            alpha = tl.math.exp2(row_max - new_max)
            exact_probability = tl.math.exp2(exact_scores - new_max[:, None])
            row_sum = row_sum * alpha + tl.sum(exact_probability, axis=1)

            v = tl.load(
                v_ptr + batch * sv_b
                + k_rows[:, None].to(tl.int64) * sv_t
                + head * sv_h
                + bv_offsets[None, :],
                mask=(k_rows < T)[:, None],
                other=0.0,
            )
            output = output * alpha[:, None] + tl.dot(
                exact_probability.to(v.dtype), v
            )
            row_max = new_max

    tl.store(
        o_ptr + ((batch * T + q_rows[:, None]) * H + head) * D
        + bv_offsets[None, :],
        (output / row_sum[:, None]).to(tl.bfloat16),
        mask=(q_rows < T)[:, None],
    )


__all__ = [
    "SolRTActiveError",
    "SolRTActiveRouter",
    "SolRTActiveLogger",
    "_forward_ptr_rt_active",
]
