"""CSR compaction for Sol-RT v3.1.

Converts a final exact mask [B*H, N, N] into:
  offsets      int64 [rows + 1]
  exact_indices int16 [total_exact]

where rows = B*H*N and row r owns:
  exact_indices[offsets[r]:offsets[r+1]]

This eliminates any fixed per-row capacity.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl

BLOCK = 64


@triton.jit
def _count_exact_kernel(
    route_mask_ptr,
    counts_ptr,
    N,
    sink_start,
    sink_end,
    sink_q_start,
    sink_q_end,
    TILE_N: tl.constexpr,
):
    row = tl.program_id(0)
    kv = tl.arange(0, TILE_N)
    valid = kv < N
    q_block = row % N

    threshold_exact = (
        tl.load(route_mask_ptr + row * N + kv, mask=valid, other=0) != 0
    )
    local_exact = tl.abs(q_block - kv) <= 1
    sink_kv = (kv >= sink_start) & (kv < sink_end)
    q_in_sink = (q_block >= sink_q_start) & (q_block < sink_q_end)

    exact = valid & (
        threshold_exact | local_exact | sink_kv | q_in_sink
    )
    count = tl.sum(exact.to(tl.int32), axis=0)
    tl.store(counts_ptr + row, count)


@triton.jit
def _scatter_exact_kernel(
    route_mask_ptr,
    offsets_ptr,
    exact_indices_ptr,
    N,
    sink_start,
    sink_end,
    sink_q_start,
    sink_q_end,
    TILE_N: tl.constexpr,
):
    row = tl.program_id(0)
    kv = tl.arange(0, TILE_N)
    valid = kv < N
    q_block = row % N

    threshold_exact = (
        tl.load(route_mask_ptr + row * N + kv, mask=valid, other=0) != 0
    )
    local_exact = tl.abs(q_block - kv) <= 1
    sink_kv = (kv >= sink_start) & (kv < sink_end)
    q_in_sink = (q_block >= sink_q_start) & (q_block < sink_q_end)

    exact = valid & (
        threshold_exact | local_exact | sink_kv | q_in_sink
    )

    prefix = tl.cumsum(exact.to(tl.int32), axis=0)
    pos = prefix - 1
    row_start = tl.load(offsets_ptr + row)

    tl.store(
        exact_indices_ptr + row_start + pos,
        kv.to(tl.int16),
        mask=exact,
    )


def compact_exact_csr(
    route_mask: torch.Tensor,
    *,
    sink_blocks=(0, 0),
    sink_q=(0, 0),
):
    """Build CSR exact list with no fixed row capacity.

    Returns:
      offsets[int64, rows+1]
      exact_indices[int16, total_exact]
      counts[int32, rows]
      max_count[int]
      total_exact[int]
      compact_ms[float]
    """
    if route_mask.ndim != 3:
        raise ValueError("route_mask must be [B*H,N,N]")

    bh, nq, nk = route_mask.shape
    if nq != nk:
        raise ValueError("route_mask must be square")
    N = nq
    rows = bh * N

    if N >= 32767:
        raise ValueError("CSR int16 exact indices require N < 32767")

    tile_n = triton.next_power_of_2(N)
    counts = torch.empty(
        (rows,), device=route_mask.device, dtype=torch.int32
    )

    ev0 = torch.cuda.Event(enable_timing=True)
    ev1 = torch.cuda.Event(enable_timing=True)
    ev0.record()

    _count_exact_kernel[(rows,)](
        route_mask,
        counts,
        N,
        int(sink_blocks[0]),
        int(sink_blocks[1]),
        int(sink_q[0]),
        int(sink_q[1]),
        TILE_N=tile_n,
        num_warps=8,
    )

    # Prefix sum remains on GPU; only two scalar syncs are taken below.
    offsets = torch.empty(
        (rows + 1,), device=route_mask.device, dtype=torch.int64
    )
    offsets[0] = 0
    torch.cumsum(counts.to(torch.int64), dim=0, out=offsets[1:])

    total_exact = int(offsets[-1].item())
    max_count = int(counts.max().item())

    exact_indices = torch.empty(
        (total_exact,), device=route_mask.device, dtype=torch.int16
    )

    if total_exact > 0:
        _scatter_exact_kernel[(rows,)](
            route_mask,
            offsets,
            exact_indices,
            N,
            int(sink_blocks[0]),
            int(sink_blocks[1]),
            int(sink_q[0]),
            int(sink_q[1]),
            TILE_N=tile_n,
            num_warps=8,
        )

    ev1.record()
    ev1.synchronize()
    compact_ms = ev0.elapsed_time(ev1)

    return (
        offsets,
        exact_indices,
        counts,
        max_count,
        total_exact,
        compact_ms,
    )


__all__ = ["compact_exact_csr"]
