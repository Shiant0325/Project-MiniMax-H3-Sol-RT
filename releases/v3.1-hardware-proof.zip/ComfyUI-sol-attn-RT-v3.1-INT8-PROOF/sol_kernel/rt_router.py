"""Experimental OptiX shadow router for MiniMax H3 Sol-Attn.

This module DOES NOT alter Sol output in v1. It reproduces Sol's block-routing
score with the same Triton expression used by the forward kernel, sends those
scores through an OptiX group-threshold router, and verifies the RT group set
against a CUDA/Torch reference.

Once parity is proven on real H3 generations, this boundary can be activated.
"""

from __future__ import annotations

import ctypes
import csv
import json
import logging
import math
import os
import threading
from datetime import datetime
from pathlib import Path

import torch
import triton
import triton.language as tl

log = logging.getLogger(__name__)

SOL_BLOCK = 64
SOL_GROUP = 32
RT_GROUP = 8


@triton.jit
def _route_scores_kernel(
    q_ptr,
    kc_ptr,
    out_ptr,
    scale_log2,
    T,
    q_block_start,
    q_count,
    sq_b, sq_t, sq_h,
    B: tl.constexpr,
    H: tl.constexpr,
    N: tl.constexpr,
    D: tl.constexpr,
    ROUTE_GROUP: tl.constexpr,
    BLOCK: tl.constexpr,
):
    kv_group, q_local, bh = tl.program_id(0), tl.program_id(1), tl.program_id(2)
    if q_local >= q_count:
        return

    batch = bh // H
    head = bh % H
    q_block = q_block_start + q_local
    q_start = q_block * BLOCK

    q_rows = q_start + tl.arange(0, BLOCK)
    d = tl.arange(0, D)
    q = tl.load(
        q_ptr
        + batch * sq_b
        + q_rows[:, None].to(tl.int64) * sq_t
        + head * sq_h
        + d[None, :],
        mask=(q_rows < T)[:, None],
        other=0.0,
    )
    q_len = tl.minimum(BLOCK, T - q_start).to(tl.float32)

    kv = kv_group * ROUTE_GROUP + tl.arange(0, ROUTE_GROUP)
    valid = kv < N
    kc = tl.load(
        kc_ptr + ((batch * N + kv[:, None]) * H + head) * D + d[None, :],
        mask=valid[:, None],
        other=0.0,
    )

    scores = tl.dot(q, kc.T).to(tl.float32) * scale_log2
    route = tl.sum(scores, axis=0) / q_len

    row = bh * q_count + q_local
    tl.store(
        out_ptr + row * N + kv,
        route,
        mask=valid,
    )


def compute_route_scores(q: torch.Tensor, kc: torch.Tensor, scale: float, q_start: int, q_count: int):
    """Return [B*H*q_count, N] FP32 using Sol's exact routing expression."""
    B, T, H, D = q.shape
    N = kc.shape[1]
    out = torch.empty((B * H * q_count, N), device=q.device, dtype=torch.float32)
    groups = triton.cdiv(N, SOL_GROUP)
    scale_log2 = float(scale) * 1.4426950408889634
    _route_scores_kernel[(groups, q_count, B * H)](
        q,
        kc,
        out,
        scale_log2,
        T,
        int(q_start),
        int(q_count),
        q.stride(0), q.stride(1), q.stride(2),
        B=B,
        H=H,
        N=N,
        D=D,
        ROUTE_GROUP=SOL_GROUP,
        BLOCK=SOL_BLOCK,
        num_warps=4,
    )
    return out


class _Native:
    def __init__(self):
        self.dll = None
        self.path = None
        self.shape = None
        self.groups = None

    @staticmethod
    def _add_cuda_dir():
        if os.name != "nt" or not hasattr(os, "add_dll_directory"):
            return
        paths = []
        cuda_path = os.environ.get("CUDA_PATH")
        if cuda_path:
            paths.append(Path(cuda_path) / "bin")
        paths.append(Path(r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.8\bin"))
        for p in paths:
            if p.exists():
                try:
                    os.add_dll_directory(str(p))
                except OSError:
                    pass

    def load(self, explicit: str = ""):
        if self.dll is not None:
            return
        self._add_cuda_dir()

        candidates = []
        if explicit:
            candidates.append(Path(explicit))
        env = os.environ.get("SOL_RT_DLL")
        if env:
            candidates.append(Path(env))

        here = Path(__file__).resolve().parents[1]
        candidates += [
            here / "sol_rt_native" / "build" / "sol_rt_router.dll",
            here / "sol_rt_native" / "build" / "Release" / "sol_rt_router.dll",
            here / "sol_rt_native" / "sol_rt_router.dll",
        ]

        dll_path = next((p for p in candidates if p.exists()), None)
        if dll_path is None:
            raise FileNotFoundError(
                "sol_rt_router.dll not found. Build sol_rt_native or set SOL_RT_DLL."
            )

        dll = ctypes.CDLL(str(dll_path))
        dll.sol_rt_init.argtypes = [ctypes.c_char_p]
        dll.sol_rt_init.restype = ctypes.c_int
        dll.sol_rt_prepare.argtypes = [
            ctypes.c_int, ctypes.c_int,
            ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float),
        ]
        dll.sol_rt_prepare.restype = ctypes.c_int
        dll.sol_rt_route.argtypes = [
            ctypes.c_uint64, ctypes.c_uint64, ctypes.c_uint64, ctypes.c_uint64,
            ctypes.c_int, ctypes.c_int,
            ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float),
        ]
        dll.sol_rt_route.restype = ctypes.c_int
        dll.sol_rt_group_size.argtypes = []
        dll.sol_rt_group_size.restype = ctypes.c_int
        dll.sol_rt_group_count.argtypes = []
        dll.sol_rt_group_count.restype = ctypes.c_int

        ptx = dll_path.with_name("rt_programs.ptx")
        rc = dll.sol_rt_init(str(ptx).encode())
        if rc:
            raise RuntimeError(f"sol_rt_init rc={rc}, PTX={ptx}")

        self.dll = dll
        self.path = dll_path
        log.info("[Sol-RT] native backend loaded: %s", dll_path)

    def prepare(self, rows: int, kv_blocks: int):
        if self.shape == (rows, kv_blocks):
            return 0.0, 0.0
        gm = ctypes.c_float()
        bm = ctypes.c_float()
        rc = self.dll.sol_rt_prepare(rows, kv_blocks, ctypes.byref(gm), ctypes.byref(bm))
        if rc:
            raise RuntimeError(f"sol_rt_prepare rc={rc}")
        self.shape = (rows, kv_blocks)
        self.groups = int(self.dll.sol_rt_group_count())
        return float(gm.value), float(bm.value)

    def route(self, scores, thresholds):
        rows, kv_blocks = scores.shape
        geom_ms, gas_ms = self.prepare(rows, kv_blocks)
        groups = int(self.groups)

        out_groups = torch.empty((rows, groups), device=scores.device, dtype=torch.int32)
        out_counts = torch.empty((rows,), device=scores.device, dtype=torch.int32)
        gm = ctypes.c_float()
        tm = ctypes.c_float()

        rc = self.dll.sol_rt_route(
            scores.data_ptr(),
            thresholds.data_ptr(),
            out_groups.data_ptr(),
            out_counts.data_ptr(),
            rows,
            kv_blocks,
            ctypes.byref(gm),
            ctypes.byref(tm),
        )
        if rc:
            raise RuntimeError(f"sol_rt_route rc={rc}")

        return out_groups, out_counts, {
            "geometry_ms": geom_ms,
            "gas_ms": gas_ms,
            "group_max_ms": float(gm.value),
            "trace_ms": float(tm.value),
        }


_NATIVE = _Native()


class SolRTSessionLogger:
    """Write one benchmark session to JSONL + CSV + rolling summary TXT."""

    CSV_FIELDS = [
        "timestamp",
        "call",
        "tokens",
        "heads",
        "route_blocks",
        "q_chunk_blocks",
        "rt_group",
        "rows",
        "mismatches",
        "setup_ms",
        "group_max_total_ms",
        "group_max_max_ms",
        "trace_total_ms",
        "trace_max_ms",
    ]

    def __init__(self, enabled=True, log_dir=""):
        self.enabled = bool(enabled)
        self.lock = threading.Lock()
        self.records = 0
        self.total_rows = 0
        self.total_mismatches = 0
        self.total_setup_ms = 0.0
        self.total_group_ms = 0.0
        self.total_trace_ms = 0.0
        self.max_trace_ms = 0.0
        self.max_group_ms = 0.0

        if not self.enabled:
            self.session_dir = None
            self.jsonl_path = None
            self.csv_path = None
            self.summary_path = None
            return

        if log_dir:
            base = Path(log_dir).expanduser()
        else:
            # .../ComfyUI/custom_nodes/<node>/sol_kernel/rt_router.py
            # -> .../ComfyUI/output/sol_rt_logs
            try:
                comfy_root = Path(__file__).resolve().parents[3]
                base = comfy_root / "output" / "sol_rt_logs"
            except Exception:
                base = Path(__file__).resolve().parents[1] / "logs"

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.session_dir = base / f"session_{stamp}"
        self.session_dir.mkdir(parents=True, exist_ok=True)
        self.jsonl_path = self.session_dir / "sol_rt_calls.jsonl"
        self.csv_path = self.session_dir / "sol_rt_calls.csv"
        self.summary_path = self.session_dir / "summary.txt"

        with self.csv_path.open("w", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, fieldnames=self.CSV_FIELDS).writeheader()

        self._write_summary()
        log.info("[Sol-RT] log session: %s", self.session_dir)

    def record(self, data):
        if not self.enabled:
            return

        row = {k: data.get(k) for k in self.CSV_FIELDS}
        with self.lock:
            with self.jsonl_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(data, ensure_ascii=False) + "\n")

            with self.csv_path.open("a", newline="", encoding="utf-8") as f:
                csv.DictWriter(f, fieldnames=self.CSV_FIELDS).writerow(row)

            self.records += 1
            self.total_rows += int(data.get("rows", 0))
            self.total_mismatches += int(data.get("mismatches", 0))
            self.total_setup_ms += float(data.get("setup_ms", 0.0))
            self.total_group_ms += float(data.get("group_max_total_ms", 0.0))
            self.total_trace_ms += float(data.get("trace_total_ms", 0.0))
            self.max_trace_ms = max(self.max_trace_ms, float(data.get("trace_max_ms", 0.0)))
            self.max_group_ms = max(self.max_group_ms, float(data.get("group_max_max_ms", 0.0)))
            self._write_summary()

    def _write_summary(self):
        if not self.enabled:
            return
        text = (
            "MiniMax H3 Sol-RT session summary\n"
            "=================================\n"
            f"session_dir: {self.session_dir}\n"
            f"records: {self.records}\n"
            f"total_rows: {self.total_rows}\n"
            f"total_mismatches: {self.total_mismatches}\n"
            f"total_setup_ms: {self.total_setup_ms:.6f}\n"
            f"total_group_max_ms: {self.total_group_ms:.6f}\n"
            f"total_rt_trace_ms: {self.total_trace_ms:.6f}\n"
            f"max_group_max_slab_ms: {self.max_group_ms:.6f}\n"
            f"max_rt_trace_slab_ms: {self.max_trace_ms:.6f}\n"
        )
        self.summary_path.write_text(text, encoding="utf-8")


class SolRTShadowValidator:
    def __init__(
        self,
        *,
        dll_path="",
        q_chunk_blocks=8,
        verify_every=1,
        strict=True,
        max_mismatch=0,
        log_files=True,
        log_dir="",
    ):
        self.dll_path = str(dll_path or "")
        self.q_chunk_blocks = max(1, int(q_chunk_blocks))
        self.verify_every = max(1, int(verify_every))
        self.strict = bool(strict)
        self.max_mismatch = int(max_mismatch)
        self.calls = 0
        self.logged_shape = None
        self.session_log = SolRTSessionLogger(enabled=log_files, log_dir=log_dir)

    def validate(self, q, kc, threshold, scale):
        self.calls += 1
        if self.calls % self.verify_every:
            return

        if torch.cuda.get_device_capability(q.device) != (12, 0):
            raise RuntimeError("Sol-RT v1 is built for SM120 (RTX 50-series)")

        _NATIVE.load(self.dll_path)

        B, T, H, D = q.shape
        N = kc.shape[1]
        q_chunks = math.ceil(N / self.q_chunk_blocks)

        total_rows = 0
        mismatches = 0
        max_group_ms = 0.0
        max_trace_ms = 0.0
        total_group_ms = 0.0
        total_trace_ms = 0.0
        setup_ms = 0.0

        for ci in range(q_chunks):
            qs = ci * self.q_chunk_blocks
            qc = min(self.q_chunk_blocks, N - qs)
            scores = compute_route_scores(q, kc, scale, qs, qc)

            # threshold is [B, N, H] -> row order [B,H,q]
            th = (
                threshold[:, qs:qs + qc, :]
                .permute(0, 2, 1)
                .contiguous()
                .reshape(-1)
                .to(torch.float32)
            )

            rt_groups, rt_counts, timing = _NATIVE.route(scores, th)
            setup_ms += timing["geometry_ms"] + timing["gas_ms"]
            total_group_ms += timing["group_max_ms"]
            total_trace_ms += timing["trace_ms"]
            max_group_ms = max(max_group_ms, timing["group_max_ms"])
            max_trace_ms = max(max_trace_ms, timing["trace_ms"])

            rows = scores.shape[0]
            groups = rt_groups.shape[1]
            pad = groups * RT_GROUP - N
            padded = torch.nn.functional.pad(scores, (0, pad), value=float("-inf")) if pad else scores
            ref_active = padded.view(rows, groups, RT_GROUP).amax(dim=-1) > th[:, None]

            rt_active = torch.zeros((rows, groups), device=q.device, dtype=torch.bool)

            slots = torch.arange(groups, device=q.device)[None, :]
            valid_slots = slots < rt_counts[:, None].clamp(max=groups)

            row_ids = (
                torch.arange(rows, device=q.device)[:, None]
                .expand(rows, groups)
            )

            valid_rows = row_ids[valid_slots]
            valid_groups = rt_groups[valid_slots]

            valid_index = (
                (valid_groups >= 0)
                & (valid_groups < groups)
            )

            rt_active[
                valid_rows[valid_index],
                valid_groups[valid_index]
            ] = True

            mismatch = (ref_active != rt_active).sum().item()
            mismatches += int(mismatch)
            total_rows += rows

        if self.logged_shape != (T, H, N):
            self.logged_shape = (T, H, N)
            log.info(
                "[Sol-RT] real H3 shadow active: tokens=%d, heads=%d, route_blocks=%d, "
                "q_chunk_blocks=%d, RT group=%d",
                T, H, N, self.q_chunk_blocks, RT_GROUP,
            )

        log.info(
            "[Sol-RT] shadow call=%d rows=%d mismatches=%d setup=%.3fms "
            "group_sum=%.3fms trace_sum=%.3fms group_max<=%.3fms trace_max<=%.3fms",
            self.calls, total_rows, mismatches, setup_ms,
            total_group_ms, total_trace_ms, max_group_ms, max_trace_ms,
        )

        self.session_log.record({
            "timestamp": datetime.now().isoformat(timespec="milliseconds"),
            "call": self.calls,
            "tokens": T,
            "heads": H,
            "route_blocks": N,
            "q_chunk_blocks": self.q_chunk_blocks,
            "rt_group": RT_GROUP,
            "rows": total_rows,
            "mismatches": mismatches,
            "setup_ms": setup_ms,
            "group_max_total_ms": total_group_ms,
            "group_max_max_ms": max_group_ms,
            "trace_total_ms": total_trace_ms,
            "trace_max_ms": max_trace_ms,
        })

        if mismatches > self.max_mismatch:
            msg = f"Sol-RT routing mismatch: {mismatches} group decisions"
            if self.strict:
                raise RuntimeError(msg)
            log.warning("[Sol-RT] %s", msg)


__all__ = ["SolRTShadowValidator", "SolRTSessionLogger", "compute_route_scores"]
