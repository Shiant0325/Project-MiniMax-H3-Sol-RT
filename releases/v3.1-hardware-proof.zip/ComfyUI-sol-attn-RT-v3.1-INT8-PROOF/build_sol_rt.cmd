@echo off
setlocal
cd /d "%~dp0sol_rt_native"
if exist build rmdir /s /q build

cmake -S . -B build ^
  -G "NMake Makefiles" ^
  -DCMAKE_BUILD_TYPE=Release ^
  -DCMAKE_CUDA_COMPILER="C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.8\bin\nvcc.exe" ^
  -DCMAKE_CUDA_ARCHITECTURES=120 ^
  -DOPTIX_ROOT="C:\ProgramData\NVIDIA Corporation\OptiX SDK 9.1.0"

if errorlevel 1 exit /b 1
cmake --build build
if errorlevel 1 exit /b 1

echo.
echo Built:
dir /b build\sol_rt_router.dll
dir /b build\rt_programs.ptx
