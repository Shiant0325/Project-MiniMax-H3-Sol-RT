"""MiniMax H3 all-block Sol + OptiX RT shadow-validation node."""

from __future__ import annotations

import logging
import torch

import comfy.model_management
import comfy.quant_ops

from .sol_kernel.fwd import sol_attn, _validate, _use_pointer_arch, _forward_ptr, BLOCK, GROUP
from .sol_kernel.preprocess import prepare
from .sol_kernel.rt_router import SolRTShadowValidator
from .minimax import _install_span_injector, _Unsupported

log = logging.getLogger(__name__)


def _sol_attn_shadow(q, k, v, validator, *, scale=None, tau=1.3, thresh_type="diag",
                     sink_blocks=(0, 0), sink_q=(0, 0)):
    """SM120 BF16 Sol forward with one shared preparation feeding RT shadow + Sol.

    Output path is the original Sol pointer kernel. RT only validates routing in v1.
    """
    arch = _validate(q, k, v, 1, thresh_type)
    if arch != (12, 0) or not _use_pointer_arch(arch):
        # Keep non-SM120 semantics untouched.
        return sol_attn(
            q, k, v, scale=scale, tau=tau, thresh_type=thresh_type,
            sink_blocks=sink_blocks, sink_q=sink_q,
        )

    scale = q.shape[-1] ** -0.5 if scale is None else float(scale)
    batch, tokens, heads, head_dim = q.shape
    blocks = (tokens + BLOCK - 1) // BLOCK
    output = torch.empty_like(q)

    kc, vc, threshold = prepare(
        q, k, v, tau=float(tau), scale=scale, thresh_type=thresh_type
    )

    # Real RT work on the same routing signal that the Sol forward uses.
    validator.validate(q, kc, threshold, scale)

    sinks = (
        int(sink_blocks[0]), int(sink_blocks[1]),
        int(sink_q[0]), int(sink_q[1]),
    )
    _forward_ptr[(1, blocks, batch * heads)](
        q, k, v, kc, vc, threshold, output,
        scale,
        *sinks,
        tokens,
        q.stride(0), q.stride(1), q.stride(2),
        k.stride(0), k.stride(1), k.stride(2),
        v.stride(0), v.stride(1), v.stride(2),
        H=heads,
        D=head_dim,
        NT=blocks,
        BV=head_dim,
        BLOCK_SIZE=BLOCK,
        GROUP_SIZE=GROUP,
    )
    return output


def _make_forward(attn, fallback_forward, validator, tau, min_tokens, strict, thresh_type, sink_conditioning):
    heads, head_dim = attn.heads, attn.head_dim
    inner = heads * head_dim

    def forward(x, rope_freqs=None, transformer_options={}):
        handoff = isinstance(x, list) and len(x) == 1 and torch.is_tensor(x[0])
        tensor = x[0] if handoff else x
        handoff_released = False
        try:
            if not torch.is_tensor(tensor):
                raise _Unsupported("attention input is not a tensor")
            s = tensor.shape[0]
            if tensor.ndim != 2 or s < min_tokens or tensor.requires_grad:
                raise _Unsupported("below min_tokens or autograd requested")
            if tensor.dtype != torch.bfloat16 or tensor.device.type != "cuda":
                raise _Unsupported("requires bfloat16 on CUDA")
            if head_dim != 128:
                raise _Unsupported(f"head_dim {head_dim} != 128")
            if torch.cuda.get_device_capability(tensor.device) != (12, 0):
                raise _Unsupported("Sol-RT v1 requires SM120")

            sink_blocks = (0, 0)
            sink_q = (0, 0)
            if sink_conditioning != "off":
                span = (transformer_options or {}).get("sol_h3_video_span")
                if span is not None:
                    video_start, video_stop = span
                    if 0 < video_start and s >= video_stop:
                        sink_blocks = (0, (video_start + 63) // 64)
                        if sink_conditioning == "exact_kv_and_rows":
                            sink_q = sink_blocks

            if handoff:
                tensor = x.pop()
            device = tensor.device
            q, k, v = attn.qkv_proj(tensor).split(inner, dim=-1)
            if handoff:
                del tensor
                handoff_released = True

            q = q.view(1, s, heads, head_dim)
            k = k.view(1, s, heads, head_dim)
            v = v.view(1, s, heads, head_dim)

            if rope_freqs is not None:
                qw = comfy.model_management.cast_to(attn.q_norm.weight, device=device)
                kw = comfy.model_management.cast_to(attn.k_norm.weight, device=device)
                comfy.quant_ops.ck.rms_rope_split_half_(
                    q, k, rope_freqs, qw, kw,
                    epsilon=attn.q_norm.eps,
                    rot_dim=rope_freqs.shape[-3] * 2,
                )
            else:
                q = attn.q_norm(q)
                k = attn.k_norm(k)

            out = _sol_attn_shadow(
                q, k, v, validator,
                tau=float(tau),
                thresh_type=thresh_type,
                sink_blocks=sink_blocks,
                sink_q=sink_q,
            )
            return attn.out_proj(out.view(s, inner))

        except _Unsupported as e:
            log.info("[Sol-RT] fallback: %s", e)
        except Exception:
            if strict:
                raise
            if handoff and not x:
                if handoff_released:
                    raise
                return fallback_forward(
                    tensor, rope_freqs=rope_freqs,
                    transformer_options=transformer_options,
                )
            log.exception("[Sol-RT] shadow error; using fallback")

        return fallback_forward(x, rope_freqs=rope_freqs, transformer_options=transformer_options)

    forward._minimax_h3_sol_rt_fallback = fallback_forward
    return forward


class MiniMaxH3SolRTShadowPatch:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL",),
                "enabled": ("BOOLEAN", {"default": True}),
                "tau": ("FLOAT", {"default": 1.3, "min": 0.0, "max": 4.0, "step": 0.05}),
                "min_tokens": ("INT", {"default": 4096, "min": 256, "max": 262144, "step": 256}),
                "q_chunk_blocks": ("INT", {
                    "default": 8, "min": 1, "max": 32, "step": 1,
                    "tooltip": "Query blocks per RT slab. 8 = 512 query tokens per slab."
                }),
                "verify_every": ("INT", {
                    "default": 1, "min": 1, "max": 100, "step": 1,
                    "tooltip": "Run RT shadow every N attention calls."
                }),
                "strict": ("BOOLEAN", {"default": True}),
                "thresh_type": (["diag", "exact"], {"default": "diag"}),
                "sink_conditioning": (
                    ["exact_kv", "exact_kv_and_rows", "off"],
                    {"default": "exact_kv"},
                ),
                "dll_path": ("STRING", {
                    "default": "",
                    "tooltip": "Optional full path to sol_rt_router.dll. Blank auto-detects sol_rt_native/build."
                }),
                "log_files": ("BOOLEAN", {
                    "default": True,
                    "tooltip": "Write JSONL + CSV + rolling summary TXT for every RT validation session."
                }),
                "log_dir": ("STRING", {
                    "default": "",
                    "tooltip": "Blank = ComfyUI/output/sol_rt_logs. Or provide a custom directory."
                }),
            }
        }

    RETURN_TYPES = ("MODEL",)
    FUNCTION = "patch"
    CATEGORY = "model_patches/attention"
    DESCRIPTION = (
        "All-50 MiniMax H3 Sol-Attn + real OptiX RT routing shadow validation. "
        "v1 preserves the original Sol output while proving CUDA/Sol vs RT routing parity."
    )

    def patch(self, model, enabled, tau, min_tokens, q_chunk_blocks, verify_every,
              strict, thresh_type, sink_conditioning, dll_path="", log_files=True, log_dir=""):
        if not enabled:
            return (model,)

        diffusion_model = model.get_model_object("diffusion_model")
        blocks = getattr(diffusion_model, "blocks", None)
        if diffusion_model.__class__.__name__ != "MiniMaxH3Model" or blocks is None:
            raise RuntimeError("MiniMaxH3SolRTShadowPatch requires MiniMaxH3Model")

        patched = model.clone()
        _install_span_injector(patched)

        validator = SolRTShadowValidator(
            dll_path=dll_path,
            q_chunk_blocks=int(q_chunk_blocks),
            verify_every=int(verify_every),
            strict=bool(strict),
            max_mismatch=0,
            log_files=bool(log_files),
            log_dir=str(log_dir or ""),
        )

        installed = 0
        for i in range(len(blocks)):
            attn = patched.get_model_object(f"diffusion_model.blocks.{i}.attn")
            path = f"diffusion_model.blocks.{i}.attn.forward"
            prior = getattr(patched, "object_patches", {}).get(path)
            fallback = prior if prior is not None else attn.forward
            if hasattr(fallback, "_minimax_h3_sol_rt_fallback"):
                fallback = fallback._minimax_h3_sol_rt_fallback

            patched.add_object_patch(
                path,
                _make_forward(
                    attn,
                    fallback,
                    validator,
                    float(tau),
                    int(min_tokens),
                    bool(strict),
                    str(thresh_type),
                    str(sink_conditioning),
                ),
            )
            installed += 1

        log.info(
            "[Sol-RT] SHADOW patched %d/%d H3 attention blocks; tau=%.2f, "
            "q_chunk_blocks=%d, verify_every=%d",
            installed, len(blocks), float(tau), int(q_chunk_blocks), int(verify_every),
        )
        return (patched,)


NODE_CLASS_MAPPINGS = {
    "MiniMaxH3SolRTShadowPatch": MiniMaxH3SolRTShadowPatch,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "MiniMaxH3SolRTShadowPatch": "MiniMax H3 Sol-RT Shadow (All Blocks)",
}
