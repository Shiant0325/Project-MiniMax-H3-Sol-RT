# MiniMax H3 Sol-RT v2 ACTIVE

This build moves the proven OptiX router from shadow validation into the actual
MiniMax H3 Sol-Attention generation path.

## What "active" means

For every H3 attention block:

1. Base Sol produces the same BF16 `kc`, `vc`, and routing threshold.
2. The same Sol routing score expression is computed in fixed query slabs.
3. CUDA computes exact maxima for 8-block RT groups.
4. OptiX RT traversal returns the candidate groups.
5. CUDA finalizes individual threshold-exact blocks **only inside the RT groups**.
6. The resulting RT-controlled route mask is consumed by the Sol attention kernel.
7. Sol still forces local ±1 and conditioning sink blocks exact.
8. Sol's approximate and exact attention arithmetic is otherwise unchanged.

So RT is no longer an observer: its candidate set drives the exact-vs-approximate
work selection used to produce the model output.

## Safety invariant

The active router checks for RT false negatives on every slab.

- RT false positives are harmless: CUDA's per-block threshold finalize removes them.
- RT false negatives are not allowed because they would change Sol routing.

With `strict=true`, any false negative aborts instead of silently changing output.

## Backends

The node exposes:

- `active_rt` — RT is part of generation.
- `shadow_validate` — v1 behavior, Sol output unchanged by RT.
- `base_sol` — pure Sol-Attn for direct A/B.

## First active test settings

    backend            = active_rt
    tau                = 1.30
    min_tokens         = 4096
    q_chunk_blocks     = 8
    strict             = true
    thresh_type        = diag
    int8_qk            = false
    int8_pv            = false
    sink_conditioning  = exact_kv
    dll_path           = blank
    log_files          = true
    log_dir            = blank

v2.0 active RT is intentionally BF16. INT8 stays available in `base_sol` until
the RT+INT8 route is separately validated.

## Logs

Default:

    ComfyUI/output/sol_rt_logs/active_YYYYMMDD_HHMMSS/

Files:

- `sol_rt_active_calls.jsonl`
- `sol_rt_active_calls.csv`
- `summary.txt`

Important fields include:

- step
- transformer block ID
- tokens / route blocks
- candidate group percentage
- threshold-exact block percentage
- false-negative block count
- route-score time
- RT trace time
- CUDA finalize time
- router total time
- Sol attention time
- total call time
- fallback state

## Native DLL

The existing v1 `sol_rt_router.dll` and `rt_programs.ptx` are compatible with v2.
No native rebuild is required when upgrading from the successfully built v1 folder.

## Important performance note

v2.0 is the first *correctness-active* architecture. It still computes a separate
routing pass before the unchanged Sol attention arithmetic. Therefore it is not
expected to be the final speed architecture.

The measurements from v2.0 tell us exactly where to perform v2.1 fusion:
compact bit masks/work lists, route/attention overlap, and elimination of
duplicated routing work.
