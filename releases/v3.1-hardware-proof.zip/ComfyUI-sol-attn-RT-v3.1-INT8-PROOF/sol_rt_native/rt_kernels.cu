#include <cuda_runtime.h>
#include <optix_types.h>
#include <float.h>
#include "rt_shared.h"

extern "C" __global__ void sol_rt_fill_group_aabbs(
    OptixAabb* out, int rows, int groups) {

    const size_t idx = (size_t)blockIdx.x * blockDim.x + threadIdx.x;
    const size_t n = (size_t)rows * groups;
    if (idx >= n) return;

    const int row = (int)(idx / groups);
    const float x = (float)row * 2.0f;

    OptixAabb a;
    a.minX = x - 0.25f; a.maxX = x + 0.25f;
    a.minY = -0.25f;     a.maxY = 0.25f;
    a.minZ = 0.0f;       a.maxZ = 2.0f;
    out[idx] = a;
}

extern "C" __global__ void sol_rt_group_max(
    const float* route_scores,
    float* group_max,
    int rows, int kv_blocks, int groups, int group_size) {

    const int row = blockIdx.x;
    if (row >= rows) return;

    const float* src = route_scores + (size_t)row * kv_blocks;
    float* dst = group_max + (size_t)row * groups;

    for (int g = threadIdx.x; g < groups; g += blockDim.x) {
        const int begin = g * group_size;
        int end = begin + group_size;
        if (end > kv_blocks) end = kv_blocks;

        float m = -FLT_MAX;
        for (int k = begin; k < end; ++k) {
            const float s = src[k];
            if (s > m) m = s;
        }
        dst[g] = m;
    }
}
