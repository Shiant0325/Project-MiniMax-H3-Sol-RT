#include <cuda.h>
#include <cuda_runtime.h>
#include <optix.h>
#include <optix_function_table_definition.h>
#include <optix_stubs.h>
#include <stdint.h>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <string>
#include "rt_shared.h"

#ifdef _WIN32
#define API __declspec(dllexport)
#else
#define API __attribute__((visibility("default")))
#endif

extern "C" __global__ void sol_rt_fill_group_aabbs(OptixAabb*, int, int);
extern "C" __global__ void sol_rt_group_max(const float*, float*, int, int, int, int);

struct __align__(OPTIX_SBT_RECORD_ALIGNMENT) EmptyRecord {
    char header[OPTIX_SBT_RECORD_HEADER_SIZE];
};

static OptixDeviceContext g_ctx = nullptr;
static OptixModule g_module = nullptr;
static OptixPipeline g_pipeline = nullptr;
static OptixProgramGroup g_raygen_pg = nullptr;
static OptixProgramGroup g_miss_pg = nullptr;
static OptixProgramGroup g_hit_pg = nullptr;
static CUdeviceptr g_raygen_rec = 0, g_miss_rec = 0, g_hit_rec = 0;

struct Cache {
    int rows = 0;
    int kv_blocks = 0;
    int groups = 0;
    float* group_max = nullptr;
    int32_t* visited_groups = nullptr;
    int32_t* counts = nullptr;
    OptixAabb* aabbs = nullptr;
    CUdeviceptr gas_out = 0;
    CUdeviceptr d_params = 0;
    OptixTraversableHandle traversable = 0;
};
static Cache g_cache;

static std::string load_text(const char* path) {
    std::ifstream f(path, std::ios::binary);
    std::ostringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

static void log_cb(unsigned int level, const char* tag, const char* msg, void*) {
    fprintf(stderr, "[Sol-RT][OptiX][%u][%s] %s\n", level, tag, msg);
}

static void free_cache() {
    if (g_cache.d_params) cudaFree((void*)g_cache.d_params);
    if (g_cache.gas_out) cudaFree((void*)g_cache.gas_out);
    if (g_cache.aabbs) cudaFree(g_cache.aabbs);
    if (g_cache.counts) cudaFree(g_cache.counts);
    if (g_cache.visited_groups) cudaFree(g_cache.visited_groups);
    if (g_cache.group_max) cudaFree(g_cache.group_max);
    g_cache = Cache{};
}

extern "C" API int sol_rt_init(const char* ptx_path) {
    if (g_ctx) return 0;
    if (cuInit(0) != CUDA_SUCCESS) return -1;
    if (optixInit() != OPTIX_SUCCESS) return -2;

    OptixDeviceContextOptions opts{};
    opts.logCallbackFunction = log_cb;
    opts.logCallbackLevel = 2;
    CUcontext cuCtx = 0;
    if (optixDeviceContextCreate(cuCtx, &opts, &g_ctx) != OPTIX_SUCCESS) return -3;

    std::string ptx = load_text(ptx_path);
    if (ptx.empty()) return -4;

    OptixModuleCompileOptions mopts{};
    OptixPipelineCompileOptions popts{};
    popts.usesMotionBlur = false;
    popts.traversableGraphFlags = OPTIX_TRAVERSABLE_GRAPH_FLAG_ALLOW_SINGLE_GAS;
    popts.numPayloadValues = 1;
    popts.numAttributeValues = 2;
    popts.exceptionFlags = OPTIX_EXCEPTION_FLAG_NONE;
    popts.pipelineLaunchParamsVariableName = "params";

    char log[8192];
    size_t logsz = sizeof(log);
    if (optixModuleCreate(g_ctx, &mopts, &popts, ptx.c_str(), ptx.size(),
                          log, &logsz, &g_module) != OPTIX_SUCCESS) {
        fprintf(stderr, "%s\n", log);
        return -5;
    }

    OptixProgramGroupOptions pgopts{};

    OptixProgramGroupDesc rg{};
    rg.kind = OPTIX_PROGRAM_GROUP_KIND_RAYGEN;
    rg.raygen.module = g_module;
    rg.raygen.entryFunctionName = "__raygen__sol_rt";
    logsz = sizeof(log);
    if (optixProgramGroupCreate(g_ctx, &rg, 1, &pgopts, log, &logsz, &g_raygen_pg) != OPTIX_SUCCESS)
        return -6;

    OptixProgramGroupDesc ms{};
    ms.kind = OPTIX_PROGRAM_GROUP_KIND_MISS;
    ms.miss.module = g_module;
    ms.miss.entryFunctionName = "__miss__sol_rt";
    logsz = sizeof(log);
    if (optixProgramGroupCreate(g_ctx, &ms, 1, &pgopts, log, &logsz, &g_miss_pg) != OPTIX_SUCCESS)
        return -7;

    OptixProgramGroupDesc hg{};
    hg.kind = OPTIX_PROGRAM_GROUP_KIND_HITGROUP;
    hg.hitgroup.moduleIS = g_module;
    hg.hitgroup.entryFunctionNameIS = "__intersection__sol_rt_aabb";
    hg.hitgroup.moduleAH = g_module;
    hg.hitgroup.entryFunctionNameAH = "__anyhit__sol_rt_filter";
    logsz = sizeof(log);
    if (optixProgramGroupCreate(g_ctx, &hg, 1, &pgopts, log, &logsz, &g_hit_pg) != OPTIX_SUCCESS)
        return -8;

    OptixProgramGroup pgs[3] = {g_raygen_pg, g_miss_pg, g_hit_pg};
    OptixPipelineLinkOptions lopts{};
    lopts.maxTraceDepth = 1;
    logsz = sizeof(log);
    if (optixPipelineCreate(g_ctx, &popts, &lopts, pgs, 3, log, &logsz, &g_pipeline) != OPTIX_SUCCESS)
        return -9;

    EmptyRecord rr{}, mr{}, hr{};
    optixSbtRecordPackHeader(g_raygen_pg, &rr);
    optixSbtRecordPackHeader(g_miss_pg, &mr);
    optixSbtRecordPackHeader(g_hit_pg, &hr);
    cudaMalloc((void**)&g_raygen_rec, sizeof(rr));
    cudaMalloc((void**)&g_miss_rec, sizeof(mr));
    cudaMalloc((void**)&g_hit_rec, sizeof(hr));
    cudaMemcpy((void*)g_raygen_rec, &rr, sizeof(rr), cudaMemcpyHostToDevice);
    cudaMemcpy((void*)g_miss_rec, &mr, sizeof(mr), cudaMemcpyHostToDevice);
    cudaMemcpy((void*)g_hit_rec, &hr, sizeof(hr), cudaMemcpyHostToDevice);
    return 0;
}

extern "C" API int sol_rt_prepare(
    int rows, int kv_blocks, float* geometry_ms, float* gas_ms) {

    if (!g_ctx || !g_pipeline) return -20;
    if (rows <= 0 || kv_blocks <= 0) return -21;

    const int groups = (kv_blocks + SOL_RT_GROUP_SIZE - 1) / SOL_RT_GROUP_SIZE;
    if (g_cache.traversable &&
        g_cache.rows == rows &&
        g_cache.kv_blocks == kv_blocks) {
        if (geometry_ms) *geometry_ms = 0.0f;
        if (gas_ms) *gas_ms = 0.0f;
        return 0;
    }

    free_cache();
    g_cache.rows = rows;
    g_cache.kv_blocks = kv_blocks;
    g_cache.groups = groups;

    const size_t gn = (size_t)rows * groups;
    cudaMalloc(&g_cache.group_max, gn * sizeof(float));
    cudaMalloc(&g_cache.visited_groups, gn * sizeof(int32_t));
    cudaMalloc(&g_cache.counts, (size_t)rows * sizeof(int32_t));
    cudaMalloc(&g_cache.aabbs, gn * sizeof(OptixAabb));
    cudaMalloc((void**)&g_cache.d_params, sizeof(RtLaunchParams));

    cudaEvent_t e0, e1;
    cudaEventCreate(&e0);
    cudaEventCreate(&e1);

    cudaEventRecord(e0);
    const int threads = 256;
    const int grid = (int)((gn + threads - 1) / threads);
    sol_rt_fill_group_aabbs<<<grid, threads>>>(g_cache.aabbs, rows, groups);
    cudaEventRecord(e1);
    cudaEventSynchronize(e1);
    if (geometry_ms) cudaEventElapsedTime(geometry_ms, e0, e1);

    uint32_t flags = OPTIX_GEOMETRY_FLAG_REQUIRE_SINGLE_ANYHIT_CALL;
    CUdeviceptr aabb_buffer = (CUdeviceptr)g_cache.aabbs;

    OptixBuildInput bi{};
    bi.type = OPTIX_BUILD_INPUT_TYPE_CUSTOM_PRIMITIVES;
    bi.customPrimitiveArray.aabbBuffers = &aabb_buffer;
    bi.customPrimitiveArray.numPrimitives = (unsigned int)gn;
    bi.customPrimitiveArray.flags = &flags;
    bi.customPrimitiveArray.numSbtRecords = 1;

    OptixAccelBuildOptions bo{};
    bo.buildFlags = OPTIX_BUILD_FLAG_PREFER_FAST_TRACE;
    bo.operation = OPTIX_BUILD_OPERATION_BUILD;

    OptixAccelBufferSizes bs{};
    if (optixAccelComputeMemoryUsage(g_ctx, &bo, &bi, 1, &bs) != OPTIX_SUCCESS)
        return -22;

    CUdeviceptr tmp = 0;
    cudaMalloc((void**)&tmp, bs.tempSizeInBytes);
    cudaMalloc((void**)&g_cache.gas_out, bs.outputSizeInBytes);

    cudaEventRecord(e0);
    if (optixAccelBuild(
            g_ctx, 0, &bo, &bi, 1,
            tmp, bs.tempSizeInBytes,
            g_cache.gas_out, bs.outputSizeInBytes,
            &g_cache.traversable, nullptr, 0) != OPTIX_SUCCESS) {
        cudaFree((void*)tmp);
        return -23;
    }
    cudaEventRecord(e1);
    cudaEventSynchronize(e1);
    if (gas_ms) cudaEventElapsedTime(gas_ms, e0, e1);

    cudaFree((void*)tmp);
    cudaEventDestroy(e0);
    cudaEventDestroy(e1);
    return 0;
}

extern "C" API int sol_rt_route(
    uint64_t route_scores_ptr,
    uint64_t thresholds_ptr,
    uint64_t out_groups_ptr,
    uint64_t out_counts_ptr,
    int rows,
    int kv_blocks,
    float* group_max_ms,
    float* trace_ms) {

    if (!g_cache.traversable ||
        g_cache.rows != rows ||
        g_cache.kv_blocks != kv_blocks)
        return -30;

    const int groups = g_cache.groups;
    cudaEvent_t e0, e1;
    cudaEventCreate(&e0);
    cudaEventCreate(&e1);

    cudaEventRecord(e0);
    sol_rt_group_max<<<rows, 128>>>(
        (const float*)route_scores_ptr,
        g_cache.group_max,
        rows, kv_blocks, groups, SOL_RT_GROUP_SIZE);
    cudaMemset(g_cache.counts, 0, (size_t)rows * sizeof(int32_t));
    cudaEventRecord(e1);
    cudaEventSynchronize(e1);
    if (group_max_ms) cudaEventElapsedTime(group_max_ms, e0, e1);

    RtLaunchParams lp{
        g_cache.group_max,
        (const float*)thresholds_ptr,
        g_cache.visited_groups,
        g_cache.counts,
        (uint32_t)rows,
        (uint32_t)groups,
        (uint64_t)g_cache.traversable
    };
    cudaMemcpy((void*)g_cache.d_params, &lp, sizeof(lp), cudaMemcpyHostToDevice);

    OptixShaderBindingTable sbt{};
    sbt.raygenRecord = g_raygen_rec;
    sbt.missRecordBase = g_miss_rec;
    sbt.missRecordStrideInBytes = sizeof(EmptyRecord);
    sbt.missRecordCount = 1;
    sbt.hitgroupRecordBase = g_hit_rec;
    sbt.hitgroupRecordStrideInBytes = sizeof(EmptyRecord);
    sbt.hitgroupRecordCount = 1;

    cudaEventRecord(e0);
    const OptixResult rc = optixLaunch(
        g_pipeline, 0, g_cache.d_params, sizeof(RtLaunchParams),
        &sbt, (unsigned int)rows, 1, 1);
    if (rc != OPTIX_SUCCESS) return -31;
    cudaEventRecord(e1);
    cudaEventSynchronize(e1);
    if (trace_ms) cudaEventElapsedTime(trace_ms, e0, e1);

    cudaMemcpyAsync(
        (void*)out_groups_ptr,
        g_cache.visited_groups,
        (size_t)rows * groups * sizeof(int32_t),
        cudaMemcpyDeviceToDevice);
    cudaMemcpyAsync(
        (void*)out_counts_ptr,
        g_cache.counts,
        (size_t)rows * sizeof(int32_t),
        cudaMemcpyDeviceToDevice);
    cudaDeviceSynchronize();

    cudaEventDestroy(e0);
    cudaEventDestroy(e1);
    return 0;
}

extern "C" API int sol_rt_group_size() { return SOL_RT_GROUP_SIZE; }
extern "C" API int sol_rt_group_count() { return g_cache.groups; }

extern "C" API void sol_rt_shutdown() {
    free_cache();
    if (g_pipeline) optixPipelineDestroy(g_pipeline);
    if (g_raygen_pg) optixProgramGroupDestroy(g_raygen_pg);
    if (g_miss_pg) optixProgramGroupDestroy(g_miss_pg);
    if (g_hit_pg) optixProgramGroupDestroy(g_hit_pg);
    g_pipeline = nullptr;
    g_raygen_pg = g_miss_pg = g_hit_pg = nullptr;

    if (g_module) optixModuleDestroy(g_module);
    g_module = nullptr;

    if (g_ctx) optixDeviceContextDestroy(g_ctx);
    g_ctx = nullptr;
}
