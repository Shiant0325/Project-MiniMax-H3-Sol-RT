#include <optix.h>
#include "rt_shared.h"

extern "C" {
__constant__ RtLaunchParams params;
}

extern "C" __global__ void __raygen__sol_rt() {
    const uint32_t row = optixGetLaunchIndex().x;
    if (row >= params.rows) return;

    const float x = static_cast<float>(row) * 2.0f;
    const float3 origin = make_float3(x, 0.0f, -1.0f);
    const float3 dir = make_float3(0.0f, 0.0f, 1.0f);

    unsigned int payload = row;
    optixTrace(
        static_cast<OptixTraversableHandle>(params.traversable),
        origin, dir,
        0.0f, 1.0e20f, 0.0f,
        OptixVisibilityMask(255),
        OPTIX_RAY_FLAG_DISABLE_CLOSESTHIT,
        0, 1, 0,
        payload
    );
}

extern "C" __global__ void __intersection__sol_rt_aabb() {
    optixReportIntersection(1.0f, 0u);
}

extern "C" __global__ void __anyhit__sol_rt_filter() {
    const uint32_t row = optixGetPayload_0();
    const uint32_t prim = optixGetPrimitiveIndex();
    const uint32_t group = prim % params.groups;
    const uint32_t prim_row = prim / params.groups;

    if (prim_row != row) {
        optixIgnoreIntersection();
        return;
    }

    const float gmax = params.group_max[(size_t)row * params.groups + group];
    const float threshold = params.thresholds[row];

    if (gmax > threshold) {
        const int slot = atomicAdd(params.visited_count + row, 1);
        if (slot < static_cast<int>(params.groups)) {
            params.visited_groups[(size_t)row * params.groups + slot] = static_cast<int32_t>(group);
        }
    }

    optixIgnoreIntersection();
}

extern "C" __global__ void __miss__sol_rt() {}
