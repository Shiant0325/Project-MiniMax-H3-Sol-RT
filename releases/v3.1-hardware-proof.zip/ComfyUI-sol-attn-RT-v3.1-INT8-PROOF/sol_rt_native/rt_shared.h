#pragma once
#include <stdint.h>

#ifndef SOL_RT_GROUP_SIZE
#define SOL_RT_GROUP_SIZE 8
#endif

struct RtLaunchParams {
    const float* group_max;
    const float* thresholds;
    int32_t* visited_groups;
    int32_t* visited_count;
    uint32_t rows;
    uint32_t groups;
    uint64_t traversable;
};
