# Sol-RT v3.1 INT8 — RT Hardware Proof Build

This build provides an external-profiler A/B control.

## native_rt
- Loads `sol_rt_router.dll`.
- Calls `_NATIVE.route(...)`.
- Wraps every native route call in an NVTX range:
  `SOL_RT_OPTIX_ROUTE call=<n> slab=<n> q=<start>:<end>`.
- The native result feeds the live generation schedule.

## cuda_control
- Does NOT call `_NATIVE.route(...)`.
- Recomputes the identical 8-block candidate predicate on CUDA:
  `group_active = max(group_scores) > threshold`.
- The rest of the generation path is unchanged.

## Proof procedure
Use identical workflow, seed, model, tau, INT8 settings, resolution and tokens.

Run A:
- backend = base_rt_split
- rt_proof_mode = native_rt
- int8_qk = true
- int8_pv = true
- output_check_calls = 0

Profile with NVIDIA Nsight. Search for `SOL_RT_OPTIX_ROUTE` and inspect the
GPU/native activity inside it.

Run B:
- backend = base_rt_split
- rt_proof_mode = cuda_control
- same remaining settings

Expected:
- The NVTX/OptiX/native RT activity exists only in Run A.
- Run B has CUDA group-max work instead.
- Candidate/exact percentages should be essentially identical.
- Generation output should remain semantically equivalent.

The text log itself is not the proof; the external NVIDIA profiler A/B is.
No native recompilation is required.
